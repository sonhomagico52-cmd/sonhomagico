/**
 * AdminDashboard — Sonho Mágico Joinville CRM
 * Área administrativa com módulos completos
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { LogOut, Users, Calendar, FileText, BarChart3, Lock, Settings, Palette, Bell, MessageSquare, HardDrive, CreditCard, TrendingUp, Zap, Award } from "lucide-react";
import { useAuth, useSuperAdmin } from "@/contexts/AuthContext";
import { toast } from "sonner";
import SuperAdminModal from "@/components/SuperAdminModal";
import ClientsModule from "@/components/ClientsModule";
import EventsModule from "@/components/EventsModule";
import LandingPageModule from "@/components/LandingPageModule";
import ReportsModule from "@/components/ReportsModule";
import MessagesModule from "@/components/MessagesModule";
import HistoryBackupModule from "@/components/HistoryBackupModule";
import PaymentsModule from "@/components/PaymentsModule";
import NotificationsPanel from "@/components/NotificationsPanel";
import AnalyticsModule from "@/components/AnalyticsModule";
import AutoSchedulingModule from "@/components/AutoSchedulingModule";
import CertificatesModule from "@/components/CertificatesModule";

export default function AdminDashboard() {
  const { user, logout, events, quotes, users, validateSuperAdminPassword } = useAuth();
  const { isSuperAdmin } = useSuperAdmin();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"dashboard" | "clients" | "events" | "landing" | "reports" | "messages" | "history" | "payments" | "analytics" | "scheduling" | "certificates" | "settings">("dashboard");
  const [showSuperAdminModal, setShowSuperAdminModal] = useState(false);

  if (!user || user.role !== "admin") {
    setLocation("/login");
    return null;
  }

  const handleLogout = () => {
    logout();
    setLocation("/");
    toast.success("Logout realizado com sucesso");
  };

  const clientUsers = users.filter((u) => u.role === "client");
  const confirmedEvents = events.filter((e) => e.status === "confirmed").length;
  const pendingEvents = events.filter((e) => e.status === "pending").length;
  const completedEvents = events.filter((e) => e.status === "completed").length;
  const totalRevenue = events.reduce((sum, e) => sum + (e.budget || 0), 0);
  const approvedQuotes = quotes.filter((q) => q.status === "approved").length;

  return (
    <div className="min-h-screen bg-[oklch(0.97_0.01_85)]">
      {/* Header */}
      <div className="bg-white shadow-md sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[oklch(0.88_0.18_85)] via-[oklch(0.55_0.28_340)] to-[oklch(0.38_0.22_262)] flex items-center justify-center">
              <span className="text-white font-bold" style={{ fontFamily: "'Baloo 2', cursive" }}>
                A
              </span>
            </div>
            <div>
              <p className="text-sm font-bold text-[oklch(0.18_0.02_260)]">Painel Admin</p>
              <p className="text-xs text-[oklch(0.18_0.02_260)]/60">{user.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <NotificationsPanel />
          </div>
          <div className="flex items-center gap-3">
            {user?.role === "admin" && !isSuperAdmin && (
              <button
                onClick={() => setShowSuperAdminModal(true)}
                className="hidden md:flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
              >
                <Lock size={16} />
                Super Admin
              </button>
            )}
            {isSuperAdmin && (
              <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-[oklch(0.65_0.25_145)] text-white text-xs font-bold">
                🔓 Super Admin Ativo
              </div>
            )}
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.65_0.25_145)] text-white font-bold hover:scale-105 transition-transform"
            >
              <LogOut size={16} />
              Sair
            </button>
          </div>
        </div>
      </div>

      <div className="container py-8">
        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-[oklch(0.92_0.02_85)] overflow-x-auto">
          {[
            { id: "dashboard", label: "Dashboard", icon: BarChart3 },
            { id: "clients", label: "Clientes", icon: Users },
            { id: "events", label: "Eventos", icon: Calendar },
            { id: "landing", label: "Landing Page", icon: Palette },
            { id: "reports", label: "Relatórios", icon: FileText },
            { id: "messages", label: "Mensagens", icon: MessageSquare },
            { id: "payments", label: "Pagamentos", icon: CreditCard },
            { id: "analytics", label: "Analytics", icon: TrendingUp },
            { id: "scheduling", label: "Agendamento", icon: Zap },
            { id: "certificates", label: "Certificados", icon: Award },
            { id: "history", label: "Histórico", icon: HardDrive },
            ...(isSuperAdmin ? [{ id: "settings", label: "Configurações", icon: Settings }] : []),
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as any)}
              className={`flex items-center gap-2 px-4 py-3 font-bold border-b-2 whitespace-nowrap transition-colors ${
                activeTab === id
                  ? "border-[oklch(0.55_0.28_340)] text-[oklch(0.55_0.28_340)]"
                  : "border-transparent text-[oklch(0.18_0.02_260)]/60 hover:text-[oklch(0.18_0.02_260)]"
              }`}
            >
              <Icon size={18} />
              {label}
            </button>
          ))}
        </div>

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div>
            <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)] mb-6" style={{ fontFamily: "'Baloo 2', cursive" }}>
              Dashboard
            </h2>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
              {[
                { label: "Clientes", value: clientUsers.length, color: "from-[oklch(0.88_0.18_85)] to-[oklch(0.72_0.22_55)]", icon: Users },
                { label: "Confirmados", value: confirmedEvents, color: "from-[oklch(0.65_0.25_145)] to-[oklch(0.55_0.22_262)]", icon: Calendar },
                { label: "Pendentes", value: pendingEvents, color: "from-[oklch(0.55_0.28_340)] to-[oklch(0.55_0.22_262)]", icon: Calendar },
                { label: "Realizados", value: completedEvents, color: "from-[oklch(0.55_0.22_262)] to-[oklch(0.38_0.22_262)]", icon: BarChart3 },
                { label: "Orçamentos", value: approvedQuotes, color: "from-[oklch(0.72_0.22_55)] to-[oklch(0.55_0.28_340)]", icon: FileText },
              ].map(({ label, value, color, icon: Icon }, idx) => (
                <div
                  key={idx}
                  className={`bg-gradient-to-br ${color} rounded-2xl shadow-lg p-6 text-white`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold opacity-80">{label}</p>
                      <p className="text-3xl font-extrabold mt-2">{value}</p>
                    </div>
                    <Icon size={32} className="opacity-30" />
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
                <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Receita Total</h3>
                <p className="text-4xl font-extrabold text-[oklch(0.55_0.28_340)]">R$ {totalRevenue.toFixed(2)}</p>
                <p className="text-sm text-[oklch(0.18_0.02_260)]/60 mt-2">De todos os eventos confirmados</p>
              </div>
              <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
                <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Taxa de Confirmação</h3>
                <p className="text-4xl font-extrabold text-[oklch(0.55_0.28_340)]">
                  {((confirmedEvents / events.length) * 100 || 0).toFixed(1)}%
                </p>
                <p className="text-sm text-[oklch(0.18_0.02_260)]/60 mt-2">{confirmedEvents} de {events.length} eventos</p>
              </div>
            </div>
          </div>
        )}

        {/* Clients Tab */}
        {activeTab === "clients" && <ClientsModule />}

        {/* Events Tab */}
        {activeTab === "events" && <EventsModule />}

        {/* Landing Page Tab */}
        {activeTab === "landing" && <LandingPageModule />}

        {/* Reports Tab */}
        {activeTab === "reports" && <ReportsModule />}

        {/* Messages Tab */}
        {activeTab === "messages" && <MessagesModule />}

        {/* Payments Tab */}
        {activeTab === "payments" && <PaymentsModule />}

        {/* Analytics Tab */}
        {activeTab === "analytics" && <AnalyticsModule />}

        {/* Scheduling Tab */}
        {activeTab === "scheduling" && <AutoSchedulingModule />}

        {/* Certificates Tab */}
        {activeTab === "certificates" && <CertificatesModule />}

        {/* History Tab */}
        {activeTab === "history" && <HistoryBackupModule />}

        {/* Settings Tab (Super Admin Only) */}
        {activeTab === "settings" && isSuperAdmin && (
          <div>
            <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)] mb-6" style={{ fontFamily: "'Baloo 2', cursive" }}>
              Configurações Avançadas
            </h2>
            <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
              <p className="text-[oklch(0.18_0.02_260)]/70">
                Configurações avançadas disponíveis para super admin. Em desenvolvimento...
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Super Admin Modal */}
      <SuperAdminModal
        isOpen={showSuperAdminModal}
        onClose={() => setShowSuperAdminModal(false)}
        onValidate={validateSuperAdminPassword}
      />
    </div>
  );
}
