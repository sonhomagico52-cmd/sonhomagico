/**
 * EventSchedule — Sonho Mágico Joinville
 * Design: Circo Moderno / Pop Festivo Brasileiro
 * Seção de agenda com calendário interativo e lista de eventos próximos
 */
import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Calendar, Clock, MapPin, Users } from "lucide-react";

interface Event {
  id: number;
  title: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  service: string;
  status: "confirmed" | "pending" | "completed";
}

// Dados de exemplo - substitua com dados reais
const EVENTS: Event[] = [
  {
    id: 1,
    title: "Festa de Aniversário - Tema Mickey",
    date: "2026-03-25",
    time: "14:00",
    location: "Bairro Centro, Joinville",
    attendees: 30,
    service: "Personagens Kids",
    status: "confirmed",
  },
  {
    id: 2,
    title: "Evento Corporativo - Confraternização",
    date: "2026-03-28",
    time: "18:00",
    location: "Salão de Eventos, Joinville",
    attendees: 100,
    service: "Recreação",
    status: "confirmed",
  },
  {
    id: 3,
    title: "Festa Infantil - Tema Princesa",
    date: "2026-04-05",
    time: "15:00",
    location: "Parque da Boca da Traição, Joinville",
    attendees: 25,
    service: "Personagens Kids",
    status: "pending",
  },
  {
    id: 4,
    title: "Carreta Furacão - Evento de Rua",
    date: "2026-04-10",
    time: "19:00",
    location: "Avenida Getúlio Vargas, Joinville",
    attendees: 200,
    service: "Carreta Furacão",
    status: "confirmed",
  },
  {
    id: 5,
    title: "Magic Drinks - Festa Temática",
    date: "2026-04-15",
    time: "20:00",
    location: "Restaurante Gourmet, Joinville",
    attendees: 60,
    service: "Magic Drinks Kids",
    status: "confirmed",
  },
];

export default function EventSchedule() {
  const [visible, setVisible] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date(2026, 2)); // Março 2026
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  // Obter eventos do mês atual
  const monthEvents = EVENTS.filter((event) => {
    const eventDate = new Date(event.date);
    return (
      eventDate.getMonth() === currentMonth.getMonth() &&
      eventDate.getFullYear() === currentMonth.getFullYear()
    );
  });

  // Obter eventos do dia selecionado
  const selectedEvents = selectedDate
    ? EVENTS.filter((event) => event.date === selectedDate)
    : EVENTS.slice(0, 3); // Mostrar os 3 próximos por padrão

  // Gerar dias do calendário
  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const daysInMonth = getDaysInMonth(currentMonth);
  const firstDay = getFirstDayOfMonth(currentMonth);
  const calendarDays = [];

  // Preencher dias vazios no início
  for (let i = 0; i < firstDay; i++) {
    calendarDays.push(null);
  }

  // Preencher dias do mês
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i);
  }

  const hasEventOnDay = (day: number) => {
    const dateStr = `2026-${String(currentMonth.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    return EVENTS.some((event) => event.date === dateStr);
  };

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
    setSelectedDate(null);
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
    setSelectedDate(null);
  };

  const handleSelectDay = (day: number) => {
    const dateStr = `2026-${String(currentMonth.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    setSelectedDate(dateStr);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-[oklch(0.65_0.25_145)] text-white";
      case "pending":
        return "bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)]";
      case "completed":
        return "bg-[oklch(0.55_0.22_262)] text-white";
      default:
        return "bg-gray-300 text-gray-700";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Confirmado";
      case "pending":
        return "Pendente";
      case "completed":
        return "Realizado";
      default:
        return status;
    }
  };

  return (
    <section id="agenda" className="py-20 bg-gradient-to-b from-white to-[oklch(0.97_0.01_85)] relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-10 right-10 text-[oklch(0.88_0.18_85)]/10 text-9xl font-bold pointer-events-none">
        📅
      </div>
      <div className="absolute bottom-20 left-5 text-[oklch(0.55_0.28_340)]/10 text-8xl font-bold pointer-events-none">
        🎉
      </div>

      <div className="container relative z-10">
        {/* Header */}
        <div ref={ref} className="text-center mb-12">
          <h2
            className={`text-3xl md:text-5xl font-extrabold text-[oklch(0.18_0.02_260)] mb-4 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ fontFamily: "'Baloo 2', cursive", transitionDelay: "0.1s" }}
          >
            Agenda de Eventos
          </h2>
          <p
            className={`text-lg text-[oklch(0.18_0.02_260)]/70 max-w-2xl mx-auto transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ fontFamily: "'Nunito', sans-serif", transitionDelay: "0.2s" }}
          >
            Confira nossos próximos eventos e reserve sua data conosco!
          </p>
        </div>

        {/* Calendar and Events Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <div
            className={`lg:col-span-1 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ transitionDelay: "0.3s" }}
          >
            <div className="bg-white rounded-3xl shadow-lg p-6 border border-[oklch(0.92_0.02_85)]">
              {/* Month Header */}
              <div className="flex items-center justify-between mb-6">
                <button
                  onClick={handlePrevMonth}
                  className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-full transition-colors"
                  aria-label="Mês anterior"
                >
                  <ChevronLeft size={20} className="text-[oklch(0.55_0.28_340)]" />
                </button>
                <h3
                  className="text-lg font-extrabold text-[oklch(0.18_0.02_260)]"
                  style={{ fontFamily: "'Baloo 2', cursive" }}
                >
                  {currentMonth.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
                </h3>
                <button
                  onClick={handleNextMonth}
                  className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-full transition-colors"
                  aria-label="Próximo mês"
                >
                  <ChevronRight size={20} className="text-[oklch(0.55_0.28_340)]" />
                </button>
              </div>

              {/* Weekday Headers */}
              <div className="grid grid-cols-7 gap-1 mb-3">
                {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"].map((day) => (
                  <div
                    key={day}
                    className="text-center text-xs font-bold text-[oklch(0.55_0.28_340)] uppercase"
                  >
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Days */}
              <div className="grid grid-cols-7 gap-1">
                {calendarDays.map((day, idx) => (
                  <button
                    key={idx}
                    onClick={() => day && handleSelectDay(day)}
                    disabled={!day}
                    className={`aspect-square flex items-center justify-center rounded-lg text-sm font-bold transition-all ${
                      !day
                        ? "text-transparent"
                        : hasEventOnDay(day)
                        ? "bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)] hover:scale-105 relative"
                        : "bg-[oklch(0.97_0.01_85)] text-[oklch(0.18_0.02_260)] hover:bg-[oklch(0.92_0.02_85)]"
                    } ${selectedDate === `2026-${String(currentMonth.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}` ? "ring-2 ring-[oklch(0.55_0.28_340)]" : ""}`}
                  >
                    {day}
                    {day && hasEventOnDay(day) && (
                      <div className="absolute bottom-1 w-1 h-1 bg-[oklch(0.55_0.28_340)] rounded-full" />
                    )}
                  </button>
                ))}
              </div>

              {/* Legend */}
              <div className="mt-6 pt-6 border-t border-[oklch(0.92_0.02_85)]">
                <p className="text-xs text-[oklch(0.18_0.02_260)]/60 font-semibold mb-2">
                  Legenda:
                </p>
                <div className="flex items-center gap-2 text-xs">
                  <div className="w-3 h-3 rounded-full bg-[oklch(0.88_0.18_85)]" />
                  <span className="text-[oklch(0.18_0.02_260)]/70">Com eventos</span>
                </div>
              </div>
            </div>
          </div>

          {/* Events List */}
          <div
            className={`lg:col-span-2 transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ transitionDelay: "0.4s" }}
          >
            <div className="space-y-4">
              {selectedEvents.length > 0 ? (
                selectedEvents.map((event, idx) => (
                  <div
                    key={event.id}
                    className="bg-white rounded-2xl shadow-md hover:shadow-lg p-5 border border-[oklch(0.92_0.02_85)] transition-all hover:scale-102 group"
                    style={{
                      animation: `slide-up 0.6s ease-out ${0.1 + idx * 0.1}s both`,
                    }}
                  >
                    {/* Event Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4
                          className="text-lg font-extrabold text-[oklch(0.18_0.02_260)] mb-1"
                          style={{ fontFamily: "'Baloo 2', cursive" }}
                        >
                          {event.title}
                        </h4>
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(event.status)}`}
                        >
                          {getStatusLabel(event.status)}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-extrabold text-[oklch(0.55_0.28_340)]">
                          {new Date(event.date).getDate()}
                        </div>
                        <div className="text-xs text-[oklch(0.18_0.02_260)]/60 uppercase font-semibold">
                          {new Date(event.date).toLocaleDateString("pt-BR", { month: "short" })}
                        </div>
                      </div>
                    </div>

                    {/* Event Details */}
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-3 text-sm text-[oklch(0.18_0.02_260)]/70">
                        <Clock size={16} className="text-[oklch(0.55_0.28_340)]" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-[oklch(0.18_0.02_260)]/70">
                        <MapPin size={16} className="text-[oklch(0.55_0.28_340)]" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-[oklch(0.18_0.02_260)]/70">
                        <Users size={16} className="text-[oklch(0.55_0.28_340)]" />
                        <span>{event.attendees} pessoas</span>
                      </div>
                    </div>

                    {/* Service Badge */}
                    <div className="flex items-center justify-between pt-3 border-t border-[oklch(0.92_0.02_85)]">
                      <span
                        className="px-3 py-1 rounded-full text-xs font-bold bg-[oklch(0.65_0.25_145)]/10 text-[oklch(0.65_0.25_145)]"
                      >
                        {event.service}
                      </span>
                      <a
                        href="https://wa.me/5547999447152?text=Olá!%20Gostaria%20de%20informações%20sobre%20um%20evento."
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm font-bold text-[oklch(0.55_0.28_340)] hover:text-[oklch(0.55_0.28_340)]/80 transition-colors"
                      >
                        Mais info →
                      </a>
                    </div>
                  </div>
                ))
              ) : (
                <div className="bg-white rounded-2xl shadow-md p-8 text-center border border-[oklch(0.92_0.02_85)]">
                  <Calendar size={48} className="mx-auto mb-4 text-[oklch(0.88_0.18_85)]/30" />
                  <p className="text-[oklch(0.18_0.02_260)]/60 font-medium">
                    Nenhum evento agendado para esta data.
                  </p>
                </div>
              )}
            </div>

            {/* CTA */}
            <div className="mt-8 p-6 rounded-2xl bg-gradient-to-r from-[oklch(0.88_0.18_85)] to-[oklch(0.55_0.28_340)] shadow-lg">
              <p
                className="text-white font-bold mb-4"
                style={{ fontFamily: "'Baloo 2', cursive" }}
              >
                Quer agendar um evento conosco?
              </p>
              <a
                href="https://wa.me/5547999447152?text=Olá!%20Gostaria%20de%20agendar%20um%20evento."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white text-[oklch(0.55_0.28_340)] font-extrabold hover:scale-105 transition-transform"
                style={{ fontFamily: "'Baloo 2', cursive" }}
              >
                <Calendar size={18} />
                Agende Agora
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
