/**
 * AnalyticsModule — Sonho Mágico Joinville CRM
 * Dashboard de analytics avançado com gráficos
 */
import { useState } from "react";
import { BarChart3, TrendingUp, Calendar, MapPin } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function AnalyticsModule() {
  const { events, users } = useAuth();
  const [timeRange, setTimeRange] = useState<"week" | "month" | "year">("month");

  const clientUsers = users.filter((u) => u.role === "client");

  // Calcular dados por período
  const getDateRange = () => {
    const now = new Date();
    let startDate = new Date();

    if (timeRange === "week") {
      startDate.setDate(now.getDate() - 7);
    } else if (timeRange === "month") {
      startDate.setMonth(now.getMonth() - 1);
    } else {
      startDate.setFullYear(now.getFullYear() - 1);
    }

    return events.filter((e) => new Date(e.date) >= startDate && new Date(e.date) <= now);
  };

  const periodEvents = getDateRange();
  const periodRevenue = periodEvents.reduce((sum, e) => sum + (e.budget || 0), 0);

  // Dados por dia da semana
  const eventsByDay = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"].map((day, idx) => ({
    day,
    count: periodEvents.filter((e) => new Date(e.date).getDay() === (idx + 1) % 7).length,
  }));

  // Dados por serviço
  const eventsByService = [
    "Personagens Kids",
    "Recreação",
    "Magic Drinks Kids",
    "Brinquedos",
    "Carreta Furacão",
  ].map((service) => ({
    service,
    count: periodEvents.filter((e) => e.service === service).length,
    revenue: periodEvents
      .filter((e) => e.service === service)
      .reduce((sum, e) => sum + (e.budget || 0), 0),
  }));

  // Dados por cidade
  const eventsByCity = Array.from(
    new Map(
      periodEvents.map((e) => [
        e.location,
        (periodEvents.filter((ev) => ev.location === e.location).length),
      ])
    ).entries()
  )
    .map(([city, count]) => ({ city, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Dados por status
  const eventsByStatus = {
    confirmed: periodEvents.filter((e) => e.status === "confirmed").length,
    pending: periodEvents.filter((e) => e.status === "pending").length,
    completed: periodEvents.filter((e) => e.status === "completed").length,
  };

  // Crescimento mês a mês
  const getMonthlyData = () => {
    const months = [];
    const now = new Date();

    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthEvents = events.filter((e) => {
        const eventDate = new Date(e.date);
        return (
          eventDate.getFullYear() === date.getFullYear() &&
          eventDate.getMonth() === date.getMonth()
        );
      });

      months.push({
        month: date.toLocaleDateString("pt-BR", { month: "short" }),
        revenue: monthEvents.reduce((sum, e) => sum + (e.budget || 0), 0),
        count: monthEvents.length,
      });
    }

    return months;
  };

  const monthlyData = getMonthlyData();

  // Encontrar máximos para escala
  const maxRevenue = Math.max(...monthlyData.map((m) => m.revenue), 1);
  const maxEvents = Math.max(...monthlyData.map((m) => m.count), 1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
          📊 Analytics Avançado
        </h2>
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value as any)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
        >
          <option value="week">Última Semana</option>
          <option value="month">Último Mês</option>
          <option value="year">Último Ano</option>
        </select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: "Receita", value: `R$ ${periodRevenue.toFixed(2)}`, color: "from-[oklch(0.55_0.28_340)] to-[oklch(0.38_0.22_262)]", icon: "💰" },
          { label: "Eventos", value: periodEvents.length, color: "from-[oklch(0.65_0.25_145)] to-[oklch(0.55_0.22_262)]", icon: "📅" },
          { label: "Confirmados", value: eventsByStatus.confirmed, color: "from-[oklch(0.88_0.18_85)] to-[oklch(0.72_0.22_55)]", icon: "✅" },
          { label: "Clientes Ativos", value: new Set(periodEvents.map((e) => e.clientId)).size, color: "from-[oklch(0.55_0.22_262)] to-[oklch(0.38_0.22_262)]", icon: "👥" },
        ].map(({ label, value, color, icon }, idx) => (
          <div key={idx} className={`bg-gradient-to-br ${color} rounded-2xl shadow-lg p-6 text-white`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold opacity-80">{label}</p>
                <p className="text-3xl font-extrabold mt-2">{value}</p>
              </div>
              <span className="text-4xl opacity-30">{icon}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Monthly Trend */}
      <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
        <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-6">Tendência Mensal</h3>
        <div className="space-y-6">
          {/* Revenue Chart */}
          <div>
            <p className="text-sm font-bold text-[oklch(0.18_0.02_260)] mb-3">Receita por Mês</p>
            <div className="flex items-end gap-2 h-32">
              {monthlyData.map((data, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                  <div
                    className="w-full bg-gradient-to-t from-[oklch(0.55_0.28_340)] to-[oklch(0.88_0.18_85)] rounded-t-lg transition-all hover:opacity-80"
                    style={{ height: `${(data.revenue / maxRevenue) * 100}%` }}
                    title={`R$ ${data.revenue.toFixed(2)}`}
                  />
                  <p className="text-xs text-[oklch(0.18_0.02_260)]/60">{data.month}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Events Chart */}
          <div>
            <p className="text-sm font-bold text-[oklch(0.18_0.02_260)] mb-3">Eventos por Mês</p>
            <div className="flex items-end gap-2 h-32">
              {monthlyData.map((data, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                  <div
                    className="w-full bg-gradient-to-t from-[oklch(0.65_0.25_145)] to-[oklch(0.88_0.18_85)] rounded-t-lg transition-all hover:opacity-80"
                    style={{ height: `${(data.count / maxEvents) * 100}%` }}
                    title={`${data.count} eventos`}
                  />
                  <p className="text-xs text-[oklch(0.18_0.02_260)]/60">{data.month}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Services & Cities */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Services */}
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Serviços Mais Utilizados</h3>
          <div className="space-y-3">
            {eventsByService
              .filter((s) => s.count > 0)
              .sort((a, b) => b.count - a.count)
              .map((service) => (
                <div key={service.service} className="flex items-center justify-between p-3 rounded-lg bg-[oklch(0.97_0.01_85)]">
                  <div className="flex-1">
                    <p className="font-bold text-[oklch(0.18_0.02_260)] text-sm">{service.service}</p>
                    <p className="text-xs text-[oklch(0.18_0.02_260)]/60">{service.count} eventos</p>
                  </div>
                  <p className="text-sm font-bold text-[oklch(0.55_0.28_340)]">R$ {service.revenue.toFixed(2)}</p>
                </div>
              ))}
          </div>
        </div>

        {/* Cities */}
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Cidades Principais</h3>
          <div className="space-y-3">
            {eventsByCity.map((city, idx) => (
              <div key={city.city} className="flex items-center gap-3 p-3 rounded-lg bg-[oklch(0.97_0.01_85)]">
                <div className="w-8 h-8 rounded-full bg-[oklch(0.55_0.28_340)] text-white flex items-center justify-center font-bold text-sm">
                  {idx + 1}
                </div>
                <div className="flex-1">
                  <p className="font-bold text-[oklch(0.18_0.02_260)] text-sm flex items-center gap-2">
                    <MapPin size={14} />
                    {city.city}
                  </p>
                  <p className="text-xs text-[oklch(0.18_0.02_260)]/60">{city.count} eventos</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Status Distribution */}
      <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
        <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-6">Distribuição de Status</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: "Confirmados", value: eventsByStatus.confirmed, color: "from-[oklch(0.65_0.25_145)] to-[oklch(0.55_0.22_262)]" },
            { label: "Pendentes", value: eventsByStatus.pending, color: "from-[oklch(0.88_0.18_85)] to-[oklch(0.72_0.22_55)]" },
            { label: "Realizados", value: eventsByStatus.completed, color: "from-[oklch(0.55_0.22_262)] to-[oklch(0.38_0.22_262)]" },
          ].map(({ label, value, color }) => (
            <div key={label} className={`bg-gradient-to-br ${color} rounded-xl p-4 text-white text-center`}>
              <p className="text-3xl font-extrabold">{value}</p>
              <p className="text-xs font-semibold opacity-80 mt-2">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
