/**
 * PaymentsModule — Sonho Mágico Joinville CRM
 * Módulo de pagamentos com Stripe (simulado)
 */
import { useState } from "react";
import { CreditCard, CheckCircle, Clock, Trash2, Eye } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Payment {
  id: string;
  quoteId: string;
  amount: number;
  status: "pendente" | "processando" | "concluido" | "falho";
  method: "cartao" | "pix" | "boleto";
  timestamp: string;
  clientName: string;
}

export default function PaymentsModule() {
  const { quotes, users, events } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState<string>("");
  const [paymentMethod, setPaymentMethod] = useState<"cartao" | "pix" | "boleto">("cartao");
  const [filterStatus, setFilterStatus] = useState<"all" | "pendente" | "processando" | "concluido" | "falho">("all");

  const approvedQuotes = quotes.filter((q) => q.status === "approved");

  const filteredPayments = filterStatus === "all" ? payments : payments.filter((p) => p.status === filterStatus);

  const handleCreatePayment = () => {
    if (!selectedQuote) {
      toast.error("Selecione um orçamento");
      return;
    }

    const quote = quotes.find((q) => q.id === selectedQuote);
    const client = users.find((u) => u.id === quote?.clientId);

    if (!quote || !client) {
      toast.error("Orçamento ou cliente não encontrado");
      return;
    }

    const newPayment: Payment = {
      id: Date.now().toString(),
      quoteId: selectedQuote,
      amount: quote.amount || 0,
      status: "processando",
      method: paymentMethod,
      timestamp: new Date().toISOString(),
      clientName: client.name,
    };

    setPayments([newPayment, ...payments]);

    // Simular processamento
    setTimeout(() => {
      setPayments((prev) =>
        prev.map((p) =>
          p.id === newPayment.id ? { ...p, status: "concluido" } : p
        )
      );
      toast.success("Pagamento processado com sucesso!");
    }, 2000);

    setSelectedQuote("");
    setShowForm(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "concluido":
        return "bg-[oklch(0.65_0.25_145)] text-white";
      case "processando":
        return "bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)]";
      case "pendente":
        return "bg-[oklch(0.55_0.28_340)] text-white";
      case "falho":
        return "bg-[oklch(0.65_0.25_27)] text-white";
      default:
        return "bg-gray-300 text-gray-700";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "concluido":
        return "Concluído";
      case "processando":
        return "Processando";
      case "pendente":
        return "Pendente";
      case "falho":
        return "Falho";
      default:
        return status;
    }
  };

  const getMethodLabel = (method: string) => {
    switch (method) {
      case "cartao":
        return "Cartão de Crédito";
      case "pix":
        return "PIX";
      case "boleto":
        return "Boleto";
      default:
        return method;
    }
  };

  const totalReceived = payments
    .filter((p) => p.status === "concluido")
    .reduce((sum, p) => sum + p.amount, 0);

  const totalPending = payments
    .filter((p) => p.status === "processando" || p.status === "pendente")
    .reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
          💳 Pagamentos
        </h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
        >
          <CreditCard size={16} />
          Novo Pagamento
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: "Total Recebido", value: `R$ ${totalReceived.toFixed(2)}`, color: "from-[oklch(0.65_0.25_145)] to-[oklch(0.55_0.22_262)]" },
          { label: "Pendente", value: `R$ ${totalPending.toFixed(2)}`, color: "from-[oklch(0.88_0.18_85)] to-[oklch(0.72_0.22_55)]" },
          { label: "Total de Pagamentos", value: payments.length, color: "from-[oklch(0.55_0.28_340)] to-[oklch(0.38_0.22_262)]" },
        ].map(({ label, value, color }, idx) => (
          <div key={idx} className={`bg-gradient-to-br ${color} rounded-2xl shadow-lg p-6 text-white`}>
            <p className="text-sm font-semibold opacity-80">{label}</p>
            <p className="text-3xl font-extrabold mt-2">{value}</p>
          </div>
        ))}
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Novo Pagamento</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-[oklch(0.18_0.02_260)] mb-2">
                Selecione um Orçamento Aprovado
              </label>
              <select
                value={selectedQuote}
                onChange={(e) => setSelectedQuote(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              >
                <option value="">-- Selecionar --</option>
                {approvedQuotes.map((q) => {
                  const client = users.find((u) => u.id === q.clientId);
                  return (
                    <option key={q.id} value={q.id}>
                      {q.title} - {client?.name} - R$ {q.amount}
                    </option>
                  );
                })}
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-[oklch(0.18_0.02_260)] mb-2">
                Método de Pagamento
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              >
                <option value="cartao">Cartão de Crédito</option>
                <option value="pix">PIX</option>
                <option value="boleto">Boleto</option>
              </select>
            </div>

            {/* Stripe Simulation */}
            <div className="p-4 rounded-lg bg-[oklch(0.97_0.01_85)] border border-[oklch(0.92_0.02_85)]">
              <p className="text-xs text-[oklch(0.18_0.02_260)]/60 mb-3">
                💳 <strong>Simulação:</strong> Este é um sistema de simulação de pagamentos. Para integração real com Stripe, configure as credenciais.
              </p>
              {paymentMethod === "cartao" && (
                <div className="space-y-2 text-xs">
                  <p className="text-[oklch(0.18_0.02_260)]/70">Dados de teste:</p>
                  <p>Cartão: 4242 4242 4242 4242</p>
                  <p>Validade: 12/25 | CVC: 123</p>
                </div>
              )}
              {paymentMethod === "pix" && (
                <p className="text-[oklch(0.18_0.02_260)]/70 text-xs">PIX será gerado após confirmação</p>
              )}
              {paymentMethod === "boleto" && (
                <p className="text-[oklch(0.18_0.02_260)]/70 text-xs">Boleto será gerado após confirmação</p>
              )}
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleCreatePayment}
                className="px-6 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
              >
                Processar Pagamento
              </button>
              <button
                onClick={() => {
                  setShowForm(false);
                  setSelectedQuote("");
                }}
                className="px-6 py-2 rounded-lg bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] font-bold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        {["all", "pendente", "processando", "concluido", "falho"].map((status) => (
          <button
            key={status}
            onClick={() => setFilterStatus(status as any)}
            className={`px-4 py-2 rounded-lg font-bold transition-colors ${
              filterStatus === status
                ? "bg-[oklch(0.55_0.28_340)] text-white"
                : "bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] hover:bg-[oklch(0.88_0.18_85)]"
            }`}
          >
            {status === "all" ? "Todos" : getStatusLabel(status)}
          </button>
        ))}
      </div>

      {/* Payments List */}
      <div className="space-y-3">
        {filteredPayments.length > 0 ? (
          filteredPayments.map((payment) => (
            <div key={payment.id} className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <CreditCard size={20} className="text-[oklch(0.55_0.28_340)]" />
                    <div>
                      <p className="font-bold text-[oklch(0.18_0.02_260)]">{payment.clientName}</p>
                      <p className="text-xs text-[oklch(0.18_0.02_260)]/60">{getMethodLabel(payment.method)}</p>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-extrabold text-[oklch(0.55_0.28_340)]">R$ {payment.amount.toFixed(2)}</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold mt-2 ${getStatusColor(payment.status)}`}>
                    {getStatusLabel(payment.status)}
                  </span>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-[oklch(0.92_0.02_85)] flex items-center justify-between">
                <p className="text-xs text-[oklch(0.18_0.02_260)]/60">
                  {new Date(payment.timestamp).toLocaleString("pt-BR")}
                </p>
                <button
                  onClick={() => {
                    setPayments(payments.filter((p) => p.id !== payment.id));
                    toast.success("Pagamento removido");
                  }}
                  className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                >
                  <Trash2 size={16} className="text-[oklch(0.65_0.25_145)]" />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-2xl shadow-md p-8 text-center border border-[oklch(0.92_0.02_85)]">
            <p className="text-[oklch(0.18_0.02_260)]/60 font-medium">Nenhum pagamento registrado</p>
          </div>
        )}
      </div>

      {/* Stripe Info */}
      <div className="p-4 rounded-lg bg-[oklch(0.97_0.01_85)] border border-[oklch(0.92_0.02_85)]">
        <p className="text-sm text-[oklch(0.18_0.02_260)]/70">
          💡 <strong>Integração Stripe:</strong> Este módulo está em modo de simulação. Para ativar pagamentos reais, configure suas credenciais do Stripe nas configurações.
        </p>
      </div>
    </div>
  );
}
