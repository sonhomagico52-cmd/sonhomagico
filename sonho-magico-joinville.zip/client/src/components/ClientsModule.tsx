/**
 * ClientsModule — Sonho Mágico Joinville CRM
 * Módulo completo de gerenciamento de clientes
 */
import { useState } from "react";
import { Plus, Trash2, Edit2, Search, Download, Mail, Phone, MapPin, Calendar } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface ClientForm {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  notes: string;
}

export default function ClientsModule() {
  const { users, addUser, updateUser, deleteUser, events } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterCity, setFilterCity] = useState("Todos");
  const [sortBy, setSortBy] = useState<"name" | "date" | "events">("name");

  const [formData, setFormData] = useState<ClientForm>({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "Joinville",
    notes: "",
  });

  const clientUsers = users.filter((u) => u.role === "client");
  
  // Filtrar e ordenar clientes
  let filteredClients = clientUsers.filter((c) =>
    (c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (filterCity === "Todos" || (c as any).city === filterCity)
  );

  if (sortBy === "name") {
    filteredClients.sort((a, b) => a.name.localeCompare(b.name));
  } else if (sortBy === "date") {
    filteredClients.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } else if (sortBy === "events") {
    filteredClients.sort((a, b) => {
      const aEvents = events.filter((e) => e.clientId === a.id).length;
      const bEvents = events.filter((e) => e.clientId === b.id).length;
      return bEvents - aEvents;
    });
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone) {
      toast.error("Preencha os campos obrigatórios");
      return;
    }

    if (editingId) {
      updateUser(editingId, formData);
      toast.success("Cliente atualizado com sucesso!");
    } else {
      addUser({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        role: "client",
      });
      toast.success("Cliente cadastrado com sucesso!");
    }

    setFormData({ name: "", email: "", phone: "", address: "", city: "Joinville", notes: "" });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (client: any) => {
    setFormData({
      name: client.name,
      email: client.email,
      phone: client.phone,
      address: client.address || "",
      city: client.city || "Joinville",
      notes: client.notes || "",
    });
    setEditingId(client.id);
    setShowForm(true);
  };

  const handleExport = () => {
    const data = filteredClients.map((c) => ({
      Nome: c.name,
      Email: c.email,
      Telefone: c.phone,
      Eventos: events.filter((e) => e.clientId === c.id).length,
      "Data de Cadastro": new Date(c.createdAt).toLocaleDateString("pt-BR"),
    }));
    const csv = [
      Object.keys(data[0]).join(","),
      ...data.map((row) => Object.values(row).join(",")),
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `clientes-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    toast.success("Clientes exportados em CSV!");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
          📋 Gerenciar Clientes
        </h2>
        <div className="flex gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)] font-bold hover:scale-105 transition-transform"
          >
            <Download size={16} />
            Exportar CSV
          </button>
          <button
            onClick={() => {
              setShowForm(!showForm);
              setEditingId(null);
              setFormData({ name: "", email: "", phone: "", address: "", city: "Joinville", notes: "" });
            }}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
          >
            <Plus size={16} />
            Novo Cliente
          </button>
        </div>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">
            {editingId ? "Editar Cliente" : "Novo Cliente"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Nome completo *"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <input
                type="email"
                placeholder="Email *"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <input
                type="tel"
                placeholder="Telefone *"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <input
                type="text"
                placeholder="Cidade"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <input
                type="text"
                placeholder="Endereço"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none md:col-span-2"
              />
              <textarea
                placeholder="Notas"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none md:col-span-2"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="px-6 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
              >
                {editingId ? "Atualizar" : "Cadastrar"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                  setFormData({ name: "", email: "", phone: "", address: "", city: "Joinville", notes: "" });
                }}
                className="px-6 py-2 rounded-lg bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] font-bold"
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-4 flex-wrap">
        <div className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] bg-white">
          <Search size={18} className="text-[oklch(0.55_0.28_340)]" />
          <input
            type="text"
            placeholder="Buscar cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="outline-none text-sm"
          />
        </div>
        <select
          value={filterCity}
          onChange={(e) => setFilterCity(e.target.value)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none text-sm"
        >
          <option>Todos</option>
          <option>Joinville</option>
          <option>Outro</option>
        </select>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none text-sm"
        >
          <option value="name">Ordenar por Nome</option>
          <option value="date">Ordenar por Data</option>
          <option value="events">Ordenar por Eventos</option>
        </select>
      </div>

      {/* Clients List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredClients.length > 0 ? (
          filteredClients.map((client) => {
            const clientEvents = events.filter((e) => e.clientId === client.id);
            return (
              <div
                key={client.id}
                className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)] hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)]">{client.name}</h3>
                    <p className="text-xs text-[oklch(0.18_0.02_260)]/60">
                      {new Date(client.createdAt).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleEdit(client)}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Edit2 size={16} className="text-[oklch(0.55_0.28_340)]" />
                    </button>
                    <button
                      onClick={() => {
                        deleteUser(client.id);
                        toast.success("Cliente deletado");
                      }}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Trash2 size={16} className="text-[oklch(0.65_0.25_145)]" />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-[oklch(0.18_0.02_260)]/70">
                    <Mail size={14} />
                    <span className="truncate">{client.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[oklch(0.18_0.02_260)]/70">
                    <Phone size={14} />
                    <span>{client.phone}</span>
                  </div>
                  {(client as any).city && (
                    <div className="flex items-center gap-2 text-[oklch(0.18_0.02_260)]/70">
                      <MapPin size={14} />
                      <span>{(client as any).city}</span>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t border-[oklch(0.92_0.02_85)]">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[oklch(0.18_0.02_260)]/60">
                      {clientEvents.length} evento{clientEvents.length !== 1 ? "s" : ""}
                    </span>
                    <span className="px-2 py-1 rounded-full text-xs font-bold bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)]">
                      Ativo
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full bg-white rounded-2xl shadow-md p-8 text-center border border-[oklch(0.92_0.02_85)]">
            <p className="text-[oklch(0.18_0.02_260)]/60 font-medium">Nenhum cliente encontrado</p>
          </div>
        )}
      </div>
    </div>
  );
}
