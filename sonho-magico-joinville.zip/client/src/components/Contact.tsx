/**
 * Contact — Sonho Mágico Joinville
 * Design: Circo Moderno / Pop Festivo Brasileiro
 * Seção de contato com formulário e informações de contato
 */
import { useEffect, useRef, useState } from "react";
import { Phone, Instagram, MapPin, Clock, Send } from "lucide-react";

const contactInfo = [
  {
    icon: <Phone size={20} />,
    label: "WhatsApp / Telefone",
    value: "(47) 99944-7152",
    href: "https://wa.me/5547999447152",
    color: "oklch(0.65 0.25 145)",
  },
  {
    icon: <Instagram size={20} />,
    label: "Instagram",
    value: "@sonhomagicojoinville",
    href: "https://contate.me/sonhomagicojoinville",
    color: "oklch(0.55 0.28 340)",
  },
  {
    icon: <MapPin size={20} />,
    label: "Atendimento",
    value: "Joinville e região — SC",
    href: null,
    color: "oklch(0.55 0.22 262)",
  },
  {
    icon: <Clock size={20} />,
    label: "Horário",
    value: "Seg–Sáb: 8h às 20h",
    href: null,
    color: "oklch(0.88 0.18 85)",
  },
];

export default function Contact() {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [form, setForm] = useState({ name: "", phone: "", event: "", message: "" });
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = encodeURIComponent(
      `Olá! Gostaria de solicitar um orçamento.\n\n*Nome:* ${form.name}\n*Telefone:* ${form.phone}\n*Tipo de evento:* ${form.event}\n*Mensagem:* ${form.message}`
    );
    window.open(`https://wa.me/5547999447152?text=${text}`, "_blank");
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section id="contato" className="py-20 bg-[oklch(0.99_0.005_85)] relative overflow-hidden">
      <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-[oklch(0.65_0.25_145/0.08)] blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 rounded-full bg-[oklch(0.55_0.28_340/0.08)] blur-3xl pointer-events-none" />

      <div className="container relative z-10">
        {/* Header */}
        <div
          ref={ref}
          className="text-center mb-14"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "opacity 0.7s ease, transform 0.7s ease",
          }}
        >
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[oklch(0.65_0.25_145/0.15)] text-[oklch(0.45_0.25_145)] text-sm font-bold mb-4"
            style={{ fontFamily: "'Baloo 2', cursive" }}
          >
            📞 Entre em Contato
          </div>
          <h2
            className="text-3xl md:text-5xl font-extrabold text-[oklch(0.18_0.02_260)] mb-4"
            style={{ fontFamily: "'Baloo 2', cursive" }}
          >
            Vamos fazer sua{" "}
            <span className="text-[oklch(0.55_0.28_340)]">festa acontecer!</span>
          </h2>
          <p
            className="text-base md:text-lg text-[oklch(0.45_0.02_260)] max-w-2xl mx-auto"
            style={{ fontFamily: "'Nunito', sans-serif" }}
          >
            Preencha o formulário abaixo e entraremos em contato pelo WhatsApp.
            Orçamento rápido, sem compromisso!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 items-start">
          {/* Contact info */}
          <div
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(-30px)",
              transition: "opacity 0.7s ease 0.2s, transform 0.7s ease 0.2s",
            }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {contactInfo.map((info) => (
                <div
                  key={info.label}
                  className="p-5 rounded-2xl bg-white border border-[oklch(0.92_0.02_85)] shadow-sm hover:shadow-md transition-shadow"
                >
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                    style={{ backgroundColor: `${info.color.replace(")", " / 0.15)")}`, color: info.color }}
                  >
                    {info.icon}
                  </div>
                  <p
                    className="text-xs text-[oklch(0.55_0.02_260)] font-semibold uppercase tracking-wide mb-1"
                    style={{ fontFamily: "'Nunito', sans-serif" }}
                  >
                    {info.label}
                  </p>
                  {info.href ? (
                    <a
                      href={info.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm font-bold text-[oklch(0.18_0.02_260)] hover:underline"
                      style={{ fontFamily: "'Baloo 2', cursive", color: info.color }}
                    >
                      {info.value}
                    </a>
                  ) : (
                    <p
                      className="text-sm font-bold text-[oklch(0.18_0.02_260)]"
                      style={{ fontFamily: "'Baloo 2', cursive" }}
                    >
                      {info.value}
                    </p>
                  )}
                </div>
              ))}
            </div>

            {/* Instagram CTA */}
            <div
              className="p-6 rounded-2xl text-white relative overflow-hidden"
              style={{
                background: "linear-gradient(135deg, oklch(0.55 0.28 340) 0%, oklch(0.72 0.22 55) 100%)",
              }}
            >
              <div className="absolute -top-6 -right-6 text-white/10 text-8xl font-bold pointer-events-none">★</div>
              <h3
                className="text-xl font-extrabold mb-2"
                style={{ fontFamily: "'Baloo 2', cursive" }}
              >
                Siga no Instagram!
              </h3>
              <p
                className="text-white/85 text-sm mb-4"
                style={{ fontFamily: "'Nunito', sans-serif" }}
              >
                Acompanhe nossos eventos, personagens e promoções. Mais de 73,7 mil seguidores!
              </p>
              <a
                href="https://contate.me/sonhomagicojoinville"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white text-[oklch(0.55_0.28_340)] font-bold text-sm hover:scale-105 transition-transform"
                style={{ fontFamily: "'Baloo 2', cursive" }}
              >
                <Instagram size={16} />
                contate.me/sonhomagicojoinville
              </a>
            </div>
          </div>

          {/* Form */}
          <div
            className="bg-white rounded-3xl shadow-xl border border-[oklch(0.92_0.02_85)] p-8"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(30px)",
              transition: "opacity 0.7s ease 0.3s, transform 0.7s ease 0.3s",
            }}
          >
            <h3
              className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)] mb-6"
              style={{ fontFamily: "'Baloo 2', cursive" }}
            >
              Solicitar Orçamento 🎉
            </h3>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div>
                <label
                  className="block text-sm font-bold text-[oklch(0.35_0.02_260)] mb-1.5"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                >
                  Seu nome *
                </label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Ex: Maria Silva"
                  className="w-full px-4 py-3 rounded-xl border border-[oklch(0.9_0.02_85)] focus:outline-none focus:border-[oklch(0.55_0.28_340)] focus:ring-2 focus:ring-[oklch(0.55_0.28_340/0.2)] text-sm transition-all"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                />
              </div>
              <div>
                <label
                  className="block text-sm font-bold text-[oklch(0.35_0.02_260)] mb-1.5"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                >
                  WhatsApp / Telefone *
                </label>
                <input
                  type="tel"
                  required
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="(47) 99999-9999"
                  className="w-full px-4 py-3 rounded-xl border border-[oklch(0.9_0.02_85)] focus:outline-none focus:border-[oklch(0.55_0.28_340)] focus:ring-2 focus:ring-[oklch(0.55_0.28_340/0.2)] text-sm transition-all"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                />
              </div>
              <div>
                <label
                  className="block text-sm font-bold text-[oklch(0.35_0.02_260)] mb-1.5"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                >
                  Tipo de evento
                </label>
                <select
                  value={form.event}
                  onChange={(e) => setForm({ ...form, event: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[oklch(0.9_0.02_85)] focus:outline-none focus:border-[oklch(0.55_0.28_340)] focus:ring-2 focus:ring-[oklch(0.55_0.28_340/0.2)] text-sm transition-all bg-white"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                >
                  <option value="">Selecione o tipo de evento</option>
                  <option value="Aniversário infantil">Aniversário infantil</option>
                  <option value="Aniversário adulto">Aniversário adulto</option>
                  <option value="Festa corporativa">Festa corporativa</option>
                  <option value="Evento escolar">Evento escolar</option>
                  <option value="Evento público">Evento público</option>
                  <option value="Outro">Outro</option>
                </select>
              </div>
              <div>
                <label
                  className="block text-sm font-bold text-[oklch(0.35_0.02_260)] mb-1.5"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                >
                  Mensagem
                </label>
                <textarea
                  rows={3}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Conte mais sobre seu evento: data, local, número de crianças, personagens desejados..."
                  className="w-full px-4 py-3 rounded-xl border border-[oklch(0.9_0.02_85)] focus:outline-none focus:border-[oklch(0.55_0.28_340)] focus:ring-2 focus:ring-[oklch(0.55_0.28_340/0.2)] text-sm transition-all resize-none"
                  style={{ fontFamily: "'Nunito', sans-serif" }}
                />
              </div>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 w-full py-4 rounded-xl bg-[oklch(0.65_0.25_145)] hover:bg-[oklch(0.58_0.25_145)] text-white font-extrabold text-base transition-all duration-200 hover:scale-[1.02] shadow-lg mt-2"
                style={{ fontFamily: "'Baloo 2', cursive" }}
              >
                {sent ? (
                  <>✅ Enviando pelo WhatsApp...</>
                ) : (
                  <>
                    <Send size={18} />
                    Enviar pelo WhatsApp
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
