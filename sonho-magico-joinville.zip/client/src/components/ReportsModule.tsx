/**
 * ReportsModule — Sonho Mágico Joinville CRM
 * Módulo de relatórios e análises avançadas
 */
import { useState } from "react";
import { BarChart3, TrendingUp, Calendar, Download } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function ReportsModule() {
  const { events, users, quotes } = useAuth();
  const [reportType, setReportType] = useState<"revenue" | "events" | "clients" | "services">("revenue");
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));

  const clientUsers = users.filter((u) => u.role === "client");

  // Calcular dados por mês
  const getMonthData = () => {
    const [year, month] = selectedMonth.split("-");
    return events.filter((e) => {
      const eventDate = new Date(e.date);
      return (
        eventDate.getFullYear() === parseInt(year) &&
        eventDate.getMonth() === parseInt(month) - 1
      );
    });
  };

  const monthEvents = getMonthData();
  const monthRevenue = monthEvents.reduce((sum, e) => sum + (e.budget || 0), 0);
  const monthConfirmed = monthEvents.filter((e) => e.status === "confirmed").length;
  const monthCompleted = monthEvents.filter((e) => e.status === "completed").length;

  // Estatísticas por serviço
  const serviceStats = [
    "Personagens Kids",
    "Recreação",
    "Magic Drinks Kids",
    "Brinquedos",
    "Carreta Furacão",
  ].map((service) => ({
    service,
    count: events.filter((e) => e.service === service).length,
    revenue: events
      .filter((e) => e.service === service)
      .reduce((sum, e) => sum + (e.budget || 0), 0),
  }));

  // Clientes mais ativos
  const topClients = clientUsers
    .map((c) => ({
      ...c,
      eventCount: events.filter((e) => e.clientId === c.id).length,
      totalSpent: events
        .filter((e) => e.clientId === c.id)
        .reduce((sum, e) => sum + (e.budget || 0), 0),
    }))
    .sort((a, b) => b.eventCount - a.eventCount)
    .slice(0, 5);

  // Gerar relatório em PDF
  const generatePDFReport = () => {
    const reportContent = `
RELATÓRIO DE EVENTOS - SONHO MÁGICO JOINVILLE
Período: ${selectedMonth}
Data de Geração: ${new Date().toLocaleDateString("pt-BR")}

=== RESUMO DO MÊS ===
Total de Eventos: ${monthEvents.length}
Eventos Confirmados: ${monthConfirmed}
Eventos Realizados: ${monthCompleted}
Receita Total: R$ ${monthRevenue.toFixed(2)}

=== EVENTOS DO MÊS ===
${monthEvents
  .map(
    (e) =>
      `- ${e.title} | ${new Date(e.date).toLocaleDateString("pt-BR")} | ${e.location} | R$ ${e.budget || 0}`
  )
  .join("\n")}

=== SERVIÇOS MAIS UTILIZADOS ===
${serviceStats
  .filter((s) => s.count > 0)
  .map((s) => `- ${s.service}: ${s.count} eventos | R$ ${s.revenue.toFixed(2)}`)
  .join("\n")}

=== CLIENTES MAIS ATIVOS ===
${topClients.map((c) => `- ${c.name}: ${c.eventCount} eventos | R$ ${c.totalSpent.toFixed(2)}`).join("\n")}
    `;

    const blob = new Blob([reportContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `relatorio-${selectedMonth}.txt`;
    a.click();
    toast.success("Relatório gerado com sucesso!");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
          📊 Relatórios e Análises
        </h2>
        <button
          onClick={generatePDFReport}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
        >
          <Download size={16} />
          Gerar Relatório
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-4 flex-wrap">
        <select
          value={reportType}
          onChange={(e) => setReportType(e.target.value as any)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
        >
          <option value="revenue">Receita</option>
          <option value="events">Eventos</option>
          <option value="clients">Clientes</option>
          <option value="services">Serviços</option>
        </select>
        <input
          type="month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
        />
      </div>

      {/* Revenue Report */}
      {reportType === "revenue" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: "Receita Total", value: `R$ ${monthRevenue.toFixed(2)}`, color: "from-[oklch(0.55_0.28_340)] to-[oklch(0.38_0.22_262)]" },
            { label: "Eventos Confirmados", value: monthConfirmed, color: "from-[oklch(0.65_0.25_145)] to-[oklch(0.55_0.22_262)]" },
            { label: "Eventos Realizados", value: monthCompleted, color: "from-[oklch(0.55_0.22_262)] to-[oklch(0.38_0.22_262)]" },
            { label: "Ticket Médio", value: `R$ ${(monthRevenue / monthEvents.length || 0).toFixed(2)}`, color: "from-[oklch(0.88_0.18_85)] to-[oklch(0.72_0.22_55)]" },
          ].map(({ label, value, color }, idx) => (
            <div key={idx} className={`bg-gradient-to-br ${color} rounded-2xl shadow-lg p-6 text-white`}>
              <p className="text-sm font-semibold opacity-80">{label}</p>
              <p className="text-3xl font-extrabold mt-2">{value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Events Report */}
      {reportType === "events" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { label: "Total de Eventos", value: monthEvents.length, color: "from-[oklch(0.55_0.28_340)] to-[oklch(0.38_0.22_262)]" },
              { label: "Confirmados", value: monthConfirmed, color: "from-[oklch(0.65_0.25_145)] to-[oklch(0.55_0.22_262)]" },
              { label: "Realizados", value: monthCompleted, color: "from-[oklch(0.55_0.22_262)] to-[oklch(0.38_0.22_262)]" },
            ].map(({ label, value, color }, idx) => (
              <div key={idx} className={`bg-gradient-to-br ${color} rounded-2xl shadow-lg p-6 text-white`}>
                <p className="text-sm font-semibold opacity-80">{label}</p>
                <p className="text-3xl font-extrabold mt-2">{value}</p>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
            <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Eventos do Mês</h3>
            <div className="space-y-2">
              {monthEvents.length > 0 ? (
                monthEvents.map((e) => (
                  <div key={e.id} className="flex items-center justify-between p-3 rounded-lg bg-[oklch(0.97_0.01_85)]">
                    <div>
                      <p className="font-bold text-[oklch(0.18_0.02_260)]">{e.title}</p>
                      <p className="text-xs text-[oklch(0.18_0.02_260)]/60">
                        {new Date(e.date).toLocaleDateString("pt-BR")} - {e.location}
                      </p>
                    </div>
                    <span className="text-sm font-bold text-[oklch(0.55_0.28_340)]">R$ {e.budget || 0}</span>
                  </div>
                ))
              ) : (
                <p className="text-[oklch(0.18_0.02_260)]/60 text-sm">Nenhum evento neste mês</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Clients Report */}
      {reportType === "clients" && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Clientes Mais Ativos</h3>
          <div className="space-y-3">
            {topClients.map((client, idx) => (
              <div key={client.id} className="flex items-center justify-between p-4 rounded-lg bg-[oklch(0.97_0.01_85)]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[oklch(0.55_0.28_340)] text-white flex items-center justify-center font-bold text-sm">
                    {idx + 1}
                  </div>
                  <div>
                    <p className="font-bold text-[oklch(0.18_0.02_260)]">{client.name}</p>
                    <p className="text-xs text-[oklch(0.18_0.02_260)]/60">{client.eventCount} eventos</p>
                  </div>
                </div>
                <p className="text-sm font-bold text-[oklch(0.55_0.28_340)]">R$ {client.totalSpent.toFixed(2)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Services Report */}
      {reportType === "services" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {serviceStats
            .filter((s) => s.count > 0)
            .map((service) => (
              <div key={service.service} className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
                <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">{service.service}</h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-[oklch(0.18_0.02_260)]/60 mb-1">Eventos</p>
                    <p className="text-3xl font-extrabold text-[oklch(0.55_0.28_340)]">{service.count}</p>
                  </div>
                  <div>
                    <p className="text-xs text-[oklch(0.18_0.02_260)]/60 mb-1">Receita</p>
                    <p className="text-2xl font-bold text-[oklch(0.55_0.28_340)]">R$ {service.revenue.toFixed(2)}</p>
                  </div>
                  <div className="pt-3 border-t border-[oklch(0.92_0.02_85)]">
                    <p className="text-xs text-[oklch(0.18_0.02_260)]/60">
                      Ticket Médio: R$ {(service.revenue / service.count).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}
