/**
 * LandingPageModule — Sonho Mágico Joinville CRM
 * Módulo de gerenciamento de landing page
 */
import { useState } from "react";
import { Save, Plus, Trash2, Edit2 } from "lucide-react";
import { toast } from "sonner";

interface HeroContent {
  title: string;
  subtitle: string;
  cta: string;
}

interface Service {
  id: string;
  emoji: string;
  title: string;
  description: string;
}

interface Testimonial {
  id: string;
  name: string;
  role: string;
  text: string;
  rating: number;
}

export default function LandingPageModule() {
  const [activeTab, setActiveTab] = useState<"hero" | "services" | "testimonials" | "faq">("hero");
  const [heroContent, setHeroContent] = useState<HeroContent>({
    title: "Sonho Mágico Joinville",
    subtitle: "Levando entretenimento para todos os públicos",
    cta: "Solicitar Orçamento",
  });

  const [services, setServices] = useState<Service[]>([
    { id: "1", emoji: "🟡", title: "Personagens Kids", description: "Mais de 160 opções de personagens vivos" },
    { id: "2", emoji: "🟢", title: "Recreação", description: "Atividades divertidas para todas as idades" },
    { id: "3", emoji: "🔵", title: "Magic Drinks Kids", description: "Bebidas mágicas e especiais" },
    { id: "4", emoji: "🟣", title: "Brinquedos", description: "Aluguel de brinquedos diversos" },
    { id: "5", emoji: "🔴", title: "Carreta Furacão", description: "Diversão sobre rodas" },
  ]);

  const [testimonials, setTestimonials] = useState<Testimonial[]>([
    { id: "1", name: "Maria Silva", role: "Mãe", text: "Adorei! As crianças se divertiram muito!", rating: 5 },
    { id: "2", name: "João Santos", role: "Empresário", text: "Profissionalismo de primeira qualidade!", rating: 5 },
  ]);

  const [newService, setNewService] = useState<Service>({ id: "", emoji: "", title: "", description: "" });
  const [newTestimonial, setNewTestimonial] = useState<Testimonial>({ id: "", name: "", role: "", text: "", rating: 5 });
  const [editingService, setEditingService] = useState<string | null>(null);
  const [editingTestimonial, setEditingTestimonial] = useState<string | null>(null);

  const handleSaveHero = () => {
    localStorage.setItem("heroContent", JSON.stringify(heroContent));
    toast.success("Hero atualizado com sucesso!");
  };

  const handleAddService = () => {
    if (!newService.title || !newService.description) {
      toast.error("Preencha todos os campos");
      return;
    }
    if (editingService) {
      setServices(services.map((s) => (s.id === editingService ? { ...newService, id: editingService } : s)));
      setEditingService(null);
      toast.success("Serviço atualizado!");
    } else {
      setServices([...services, { ...newService, id: Date.now().toString() }]);
      toast.success("Serviço adicionado!");
    }
    setNewService({ id: "", emoji: "", title: "", description: "" });
    localStorage.setItem("services", JSON.stringify(services));
  };

  const handleAddTestimonial = () => {
    if (!newTestimonial.name || !newTestimonial.text) {
      toast.error("Preencha todos os campos");
      return;
    }
    if (editingTestimonial) {
      setTestimonials(testimonials.map((t) => (t.id === editingTestimonial ? { ...newTestimonial, id: editingTestimonial } : t)));
      setEditingTestimonial(null);
      toast.success("Depoimento atualizado!");
    } else {
      setTestimonials([...testimonials, { ...newTestimonial, id: Date.now().toString() }]);
      toast.success("Depoimento adicionado!");
    }
    setNewTestimonial({ id: "", name: "", role: "", text: "", rating: 5 });
    localStorage.setItem("testimonials", JSON.stringify(testimonials));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
        🎨 Gerenciar Landing Page
      </h2>

      {/* Tabs */}
      <div className="flex gap-4 border-b border-[oklch(0.92_0.02_85)] overflow-x-auto">
        {[
          { id: "hero", label: "Hero" },
          { id: "services", label: "Serviços" },
          { id: "testimonials", label: "Depoimentos" },
          { id: "faq", label: "FAQ" },
        ].map(({ id, label }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id as any)}
            className={`px-4 py-3 font-bold border-b-2 whitespace-nowrap transition-colors ${
              activeTab === id
                ? "border-[oklch(0.55_0.28_340)] text-[oklch(0.55_0.28_340)]"
                : "border-transparent text-[oklch(0.18_0.02_260)]/60"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Hero Tab */}
      {activeTab === "hero" && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Editar Seção Hero</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-[oklch(0.18_0.02_260)] mb-2">Título Principal</label>
              <input
                type="text"
                value={heroContent.title}
                onChange={(e) => setHeroContent({ ...heroContent, title: e.target.value })}
                className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-[oklch(0.18_0.02_260)] mb-2">Subtítulo</label>
              <input
                type="text"
                value={heroContent.subtitle}
                onChange={(e) => setHeroContent({ ...heroContent, subtitle: e.target.value })}
                className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-[oklch(0.18_0.02_260)] mb-2">Texto do Botão CTA</label>
              <input
                type="text"
                value={heroContent.cta}
                onChange={(e) => setHeroContent({ ...heroContent, cta: e.target.value })}
                className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
            </div>
            <button
              onClick={handleSaveHero}
              className="flex items-center gap-2 px-6 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
            >
              <Save size={16} />
              Salvar Alterações
            </button>
          </div>
        </div>
      )}

      {/* Services Tab */}
      {activeTab === "services" && (
        <div className="space-y-6">
          {/* Add/Edit Service */}
          <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
            <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">
              {editingService ? "Editar Serviço" : "Adicionar Novo Serviço"}
            </h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Emoji (ex: 🟡)"
                  value={newService.emoji}
                  onChange={(e) => setNewService({ ...newService, emoji: e.target.value })}
                  className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
                  maxLength={2}
                />
                <input
                  type="text"
                  placeholder="Título do Serviço"
                  value={newService.title}
                  onChange={(e) => setNewService({ ...newService, title: e.target.value })}
                  className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
                />
              </div>
              <textarea
                placeholder="Descrição do Serviço"
                value={newService.description}
                onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <div className="flex gap-2">
                <button
                  onClick={handleAddService}
                  className="flex items-center gap-2 px-6 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
                >
                  <Plus size={16} />
                  {editingService ? "Atualizar" : "Adicionar"}
                </button>
                {editingService && (
                  <button
                    onClick={() => {
                      setEditingService(null);
                      setNewService({ id: "", emoji: "", title: "", description: "" });
                    }}
                    className="px-6 py-2 rounded-lg bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] font-bold"
                  >
                    Cancelar
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Services List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {services.map((service) => (
              <div key={service.id} className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{service.emoji}</span>
                    <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)]">{service.title}</h3>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        setNewService(service);
                        setEditingService(service.id);
                      }}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Edit2 size={16} className="text-[oklch(0.55_0.28_340)]" />
                    </button>
                    <button
                      onClick={() => {
                        setServices(services.filter((s) => s.id !== service.id));
                        toast.success("Serviço removido!");
                      }}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Trash2 size={16} className="text-[oklch(0.65_0.25_145)]" />
                    </button>
                  </div>
                </div>
                <p className="text-sm text-[oklch(0.18_0.02_260)]/70">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Testimonials Tab */}
      {activeTab === "testimonials" && (
        <div className="space-y-6">
          {/* Add/Edit Testimonial */}
          <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
            <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">
              {editingTestimonial ? "Editar Depoimento" : "Adicionar Novo Depoimento"}
            </h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Nome"
                  value={newTestimonial.name}
                  onChange={(e) => setNewTestimonial({ ...newTestimonial, name: e.target.value })}
                  className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Cargo/Função"
                  value={newTestimonial.role}
                  onChange={(e) => setNewTestimonial({ ...newTestimonial, role: e.target.value })}
                  className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
                />
              </div>
              <textarea
                placeholder="Depoimento"
                value={newTestimonial.text}
                onChange={(e) => setNewTestimonial({ ...newTestimonial, text: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <select
                value={newTestimonial.rating}
                onChange={(e) => setNewTestimonial({ ...newTestimonial, rating: parseInt(e.target.value) })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              >
                <option value="5">⭐⭐⭐⭐⭐ 5 Estrelas</option>
                <option value="4">⭐⭐⭐⭐ 4 Estrelas</option>
                <option value="3">⭐⭐⭐ 3 Estrelas</option>
              </select>
              <div className="flex gap-2">
                <button
                  onClick={handleAddTestimonial}
                  className="flex items-center gap-2 px-6 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
                >
                  <Plus size={16} />
                  {editingTestimonial ? "Atualizar" : "Adicionar"}
                </button>
                {editingTestimonial && (
                  <button
                    onClick={() => {
                      setEditingTestimonial(null);
                      setNewTestimonial({ id: "", name: "", role: "", text: "", rating: 5 });
                    }}
                    className="px-6 py-2 rounded-lg bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] font-bold"
                  >
                    Cancelar
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Testimonials List */}
          <div className="space-y-4">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)]">{testimonial.name}</h3>
                    <p className="text-sm text-[oklch(0.18_0.02_260)]/60">{testimonial.role}</p>
                    <p className="text-sm mt-1">{"⭐".repeat(testimonial.rating)}</p>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => {
                        setNewTestimonial(testimonial);
                        setEditingTestimonial(testimonial.id);
                      }}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Edit2 size={16} className="text-[oklch(0.55_0.28_340)]" />
                    </button>
                    <button
                      onClick={() => {
                        setTestimonials(testimonials.filter((t) => t.id !== testimonial.id));
                        toast.success("Depoimento removido!");
                      }}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Trash2 size={16} className="text-[oklch(0.65_0.25_145)]" />
                    </button>
                  </div>
                </div>
                <p className="text-sm text-[oklch(0.18_0.02_260)]/70 italic">"{testimonial.text}"</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* FAQ Tab */}
      {activeTab === "faq" && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">Gerenciar FAQ</h3>
          <p className="text-[oklch(0.18_0.02_260)]/70 mb-4">
            A seção de FAQ está integrada na página principal. Para adicionar/editar perguntas, acesse o componente FAQ na página Home.
          </p>
          <div className="p-4 rounded-lg bg-[oklch(0.97_0.01_85)] border border-[oklch(0.92_0.02_85)]">
            <p className="text-sm text-[oklch(0.18_0.02_260)]/60">
              💡 Dica: Adicione perguntas frequentes que seus clientes fazem sobre os serviços, preços e disponibilidade.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
