/**
 * MessagesModule — Sonho Mágico Joinville CRM
 * Módulo de templates de mensagens e integração WhatsApp
 */
import { useState } from "react";
import { Plus, Trash2, Edit2, Send, Copy } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface MessageTemplate {
  id: string;
  name: string;
  category: "confirmacao" | "agradecimento" | "follow_up" | "promocao";
  content: string;
  variables: string[];
}

const DEFAULT_TEMPLATES: MessageTemplate[] = [
  {
    id: "1",
    name: "Confirmação de Evento",
    category: "confirmacao",
    content: "Olá {cliente}! 🎉 Confirmamos seu evento '{evento}' para {data} em {local}. Telefone: (47) 99944-7152",
    variables: ["cliente", "evento", "data", "local"],
  },
  {
    id: "2",
    name: "Agradecimento Pós-Evento",
    category: "agradecimento",
    content: "Obrigado {cliente}! 🙏 Esperamos que o evento '{evento}' tenha sido incrível! Qualquer dúvida, nos contacte.",
    variables: ["cliente", "evento"],
  },
  {
    id: "3",
    name: "Follow-up de Orçamento",
    category: "follow_up",
    content: "Oi {cliente}! 👋 Tudo bem? Gostaria de saber se você tem interesse no orçamento de R$ {valor} para o evento '{evento}'.",
    variables: ["cliente", "valor", "evento"],
  },
  {
    id: "4",
    name: "Promoção Especial",
    category: "promocao",
    content: "🎊 Promoção Especial! Ganhe {desconto}% de desconto em nossos serviços. Aproveite! Informações: (47) 99944-7152",
    variables: ["desconto"],
  },
];

export default function MessagesModule() {
  const { users, events } = useAuth();
  const [templates, setTemplates] = useState<MessageTemplate[]>(DEFAULT_TEMPLATES);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<MessageTemplate | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  const [formData, setFormData] = useState<MessageTemplate>({
    id: "",
    name: "",
    category: "confirmacao",
    content: "",
    variables: [],
  });

  const [previewData, setPreviewData] = useState<Record<string, string>>({});

  const clientUsers = users.filter((u) => u.role === "client");

  const handleAddTemplate = () => {
    if (!formData.name || !formData.content) {
      toast.error("Preencha todos os campos");
      return;
    }

    // Extrair variáveis do conteúdo
    const variableMatches = formData.content.match(/\{(\w+)\}/g) || [];
    const variables = variableMatches.map((v) => v.slice(1, -1));

    if (editingId) {
      setTemplates(
        templates.map((t) =>
          t.id === editingId
            ? { ...formData, id: editingId, variables }
            : t
        )
      );
      toast.success("Template atualizado!");
    } else {
      setTemplates([
        ...templates,
        { ...formData, id: Date.now().toString(), variables },
      ]);
      toast.success("Template criado!");
    }

    setFormData({
      id: "",
      name: "",
      category: "confirmacao",
      content: "",
      variables: [],
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (template: MessageTemplate) => {
    setFormData(template);
    setEditingId(template.id);
    setShowForm(true);
  };

  const handlePreview = (template: MessageTemplate) => {
    setSelectedTemplate(template);
    setShowPreview(true);
    setPreviewData({});
  };

  const generateMessage = () => {
    if (!selectedTemplate) return "";
    let message = selectedTemplate.content;
    Object.entries(previewData).forEach(([key, value]) => {
      message = message.replace(`{${key}}`, value);
    });
    return message;
  };

  const handleSendWhatsApp = () => {
    const message = generateMessage();
    const whatsappUrl = `https://wa.me/5547999447152?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
    toast.success("Abrindo WhatsApp...");
  };

  const handleCopyMessage = () => {
    const message = generateMessage();
    navigator.clipboard.writeText(message);
    toast.success("Mensagem copiada!");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
          💬 Templates de Mensagens
        </h2>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditingId(null);
            setFormData({
              id: "",
              name: "",
              category: "confirmacao",
              content: "",
              variables: [],
            });
          }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
        >
          <Plus size={16} />
          Novo Template
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">
            {editingId ? "Editar Template" : "Novo Template"}
          </h3>
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Nome do template"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
            />
            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
              className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
            >
              <option value="confirmacao">Confirmação</option>
              <option value="agradecimento">Agradecimento</option>
              <option value="follow_up">Follow-up</option>
              <option value="promocao">Promoção</option>
            </select>
            <textarea
              placeholder="Conteúdo da mensagem (use {variavel} para placeholders)"
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              rows={5}
              className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
            />
            <div className="p-3 rounded-lg bg-[oklch(0.97_0.01_85)] border border-[oklch(0.92_0.02_85)]">
              <p className="text-xs text-[oklch(0.18_0.02_260)]/60">
                💡 Use {"{variavel}"} para criar placeholders dinâmicos. Exemplo: {"{cliente}"}, {"{evento}"}, {"{data}"}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleAddTemplate}
                className="px-6 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
              >
                {editingId ? "Atualizar" : "Criar"}
              </button>
              <button
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                  setFormData({
                    id: "",
                    name: "",
                    category: "confirmacao",
                    content: "",
                    variables: [],
                  });
                }}
                className="px-6 py-2 rounded-lg bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] font-bold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {templates.map((template) => (
          <div key={template.id} className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)]">{template.name}</h3>
                <span className="text-xs px-2 py-1 rounded-full bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)] font-bold">
                  {template.category}
                </span>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={() => handleEdit(template)}
                  className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                >
                  <Edit2 size={16} className="text-[oklch(0.55_0.28_340)]" />
                </button>
                <button
                  onClick={() => {
                    setTemplates(templates.filter((t) => t.id !== template.id));
                    toast.success("Template removido!");
                  }}
                  className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                >
                  <Trash2 size={16} className="text-[oklch(0.65_0.25_145)]" />
                </button>
              </div>
            </div>

            <p className="text-sm text-[oklch(0.18_0.02_260)]/70 mb-4 line-clamp-2">{template.content}</p>

            <button
              onClick={() => handlePreview(template)}
              className="w-full px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform text-sm"
            >
              Usar Template
            </button>
          </div>
        ))}
      </div>

      {/* Preview Modal */}
      {showPreview && selectedTemplate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-8">
            <h3 className="text-2xl font-bold text-[oklch(0.18_0.02_260)] mb-4">{selectedTemplate.name}</h3>

            {/* Variables Form */}
            {selectedTemplate.variables.length > 0 && (
              <div className="space-y-3 mb-6">
                <p className="text-sm font-bold text-[oklch(0.18_0.02_260)]">Preencha as variáveis:</p>
                {selectedTemplate.variables.map((variable) => (
                  <input
                    key={variable}
                    type="text"
                    placeholder={variable}
                    value={previewData[variable] || ""}
                    onChange={(e) =>
                      setPreviewData({ ...previewData, [variable]: e.target.value })
                    }
                    className="w-full px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
                  />
                ))}
              </div>
            )}

            {/* Message Preview */}
            <div className="bg-[oklch(0.97_0.01_85)] rounded-lg p-4 mb-6">
              <p className="text-sm text-[oklch(0.18_0.02_260)] whitespace-pre-wrap">{generateMessage()}</p>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={handleCopyMessage}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)] font-bold hover:scale-105 transition-transform"
              >
                <Copy size={16} />
                Copiar
              </button>
              <button
                onClick={handleSendWhatsApp}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.65_0.25_145)] text-white font-bold hover:scale-105 transition-transform"
              >
                <Send size={16} />
                Enviar WhatsApp
              </button>
              <button
                onClick={() => {
                  setShowPreview(false);
                  setSelectedTemplate(null);
                }}
                className="flex-1 px-4 py-2 rounded-lg bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] font-bold"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
