/**
 * Services — Sonho Mágico Joinville
 * Design: Circo Moderno / Pop Festivo Brasileiro
 * Cards de serviços com imagens geradas, ícones coloridos e animações de entrada
 */
import { useEffect, useRef, useState } from "react";

const PERSONAGENS_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663459073288/DQjHD4gKJEAWCYtu4KPsKB/personagens-section-Exh3onDhxN6EJvkDG33D5y.webp";
const RECREACAO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663459073288/DQjHD4gKJEAWCYtu4KPsKB/recreacao-section-hpLeKDFaYmTxVhKG4uG6Qu.webp";
const MAGIC_DRINKS_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663459073288/DQjHD4gKJEAWCYtu4KPsKB/magic-drinks-eSkbWxMAicco8BUscoCUi2.webp";
const CARRETA_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663459073288/DQjHD4gKJEAWCYtu4KPsKB/carreta-furacao-nanAAGVXYhAHdjkW987JJb.webp";

const services = [
  {
    id: 1,
    emoji: "🟡",
    title: "Personagens Kids",
    description:
      "Mais de 160 opções de personagens vivos! Princesas, super-heróis, personagens da Disney, animê e muito mais. Fantasias de alta qualidade que encantam crianças e adultos.",
    image: PERSONAGENS_IMG,
    color: "oklch(0.88 0.18 85)",
    bgColor: "oklch(0.97 0.05 85)",
    badge: "160+ personagens",
  },
  {
    id: 2,
    emoji: "🟢",
    title: "Recreação",
    description:
      "Animadores profissionais e criativos que transformam qualquer evento em uma festa inesquecível. Brincadeiras, gincanas, pintura facial e muito mais para animar a galera!",
    image: RECREACAO_IMG,
    color: "oklch(0.65 0.25 145)",
    bgColor: "oklch(0.97 0.05 145)",
    badge: "Para todas as idades",
  },
  {
    id: 3,
    emoji: "🔵",
    title: "Magic Drinks Kids",
    description:
      "Bebidas mágicas e coloridas que encantam as crianças! Sucos especiais, vitaminas e drinks temáticos sem álcool, servidos com apresentação divertida e criativa.",
    image: MAGIC_DRINKS_IMG,
    color: "oklch(0.55 0.22 262)",
    bgColor: "oklch(0.97 0.04 262)",
    badge: "100% sem álcool",
  },
  {
    id: 4,
    emoji: "🟣",
    title: "Brinquedos",
    description:
      "Ampla variedade de brinquedos e equipamentos para festas: cama elástica, piscina de bolinhas, tobogã inflável, escorregador e muito mais para a diversão das crianças.",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80",
    color: "oklch(0.55 0.25 300)",
    bgColor: "oklch(0.97 0.04 300)",
    badge: "Aluguel e montagem",
  },
  {
    id: 5,
    emoji: "🔴",
    title: "Carreta Furacão",
    description:
      "O espetáculo que todo mundo ama! A famosa Carreta Furacão chega com música ao vivo, personagens, luzes e muita animação. Um show completo que vai agitar qualquer evento!",
    image: CARRETA_IMG,
    color: "oklch(0.55 0.25 25)",
    bgColor: "oklch(0.97 0.04 25)",
    badge: "Show completo",
  },
];

function ServiceCard({ service, index }: { service: typeof services[0]; index: number }) {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="service-card rounded-3xl overflow-hidden shadow-lg bg-white border border-[oklch(0.92_0.02_85)]"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(40px)",
        transition: `opacity 0.6s ease, transform 0.6s ease`,
        transitionDelay: `${index * 0.1}s`,
      }}
    >
      {/* Image */}
      <div className="relative h-52 overflow-hidden">
        <img
          src={service.image}
          alt={service.title}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        {/* Color overlay at bottom */}
        <div
          className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"
        />
        {/* Badge */}
        <div
          className="absolute bottom-3 left-3 px-3 py-1 rounded-full text-xs font-bold text-white"
          style={{ backgroundColor: service.color }}
        >
          {service.badge}
        </div>
        {/* Emoji indicator */}
        <div className="absolute top-3 right-3 text-2xl">{service.emoji}</div>
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Top colored bar */}
        <div
          className="w-12 h-1.5 rounded-full mb-3"
          style={{ backgroundColor: service.color }}
        />
        <h3
          className="text-xl font-extrabold text-[oklch(0.18_0.02_260)] mb-2"
          style={{ fontFamily: "'Baloo 2', cursive" }}
        >
          {service.title}
        </h3>
        <p
          className="text-sm text-[oklch(0.45_0.02_260)] leading-relaxed"
          style={{ fontFamily: "'Nunito', sans-serif" }}
        >
          {service.description}
        </p>

        {/* CTA */}
        <a
          href="https://wa.me/5547999447152"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold transition-colors"
          style={{ color: service.color, fontFamily: "'Baloo 2', cursive" }}
        >
          Solicitar orçamento →
        </a>
      </div>
    </div>
  );
}

export default function Services() {
  const [titleVisible, setTitleVisible] = useState(false);
  const titleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setTitleVisible(true); },
      { threshold: 0.2 }
    );
    if (titleRef.current) observer.observe(titleRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="servicos" className="py-20 bg-[oklch(0.99_0.005_85)] relative overflow-hidden">
      {/* Decorative background circles */}
      <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-[oklch(0.88_0.18_85/0.15)] blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-[oklch(0.55_0.28_340/0.1)] blur-3xl pointer-events-none" />

      <div className="container relative z-10">
        {/* Section header */}
        <div
          ref={titleRef}
          className="text-center mb-14"
          style={{
            opacity: titleVisible ? 1 : 0,
            transform: titleVisible ? "translateY(0)" : "translateY(30px)",
            transition: "opacity 0.7s ease, transform 0.7s ease",
          }}
        >
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[oklch(0.55_0.28_340/0.1)] text-[oklch(0.55_0.28_340)] text-sm font-bold mb-4"
            style={{ fontFamily: "'Baloo 2', cursive" }}
          >
            🎪 Nossos Serviços
          </div>
          <h2
            className="text-3xl md:text-5xl font-extrabold text-[oklch(0.18_0.02_260)] mb-4"
            style={{ fontFamily: "'Baloo 2', cursive" }}
          >
            Tudo para a sua{" "}
            <span className="text-[oklch(0.55_0.28_340)]">festa perfeita</span>
          </h2>
          <p
            className="text-base md:text-lg text-[oklch(0.45_0.02_260)] max-w-2xl mx-auto"
            style={{ fontFamily: "'Nunito', sans-serif" }}
          >
            Do personagem favorito ao show da Carreta Furacão — oferecemos uma experiência
            completa de entretenimento para eventos de todos os tamanhos.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <ServiceCard key={service.id} service={service} index={index} />
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <a
            href="https://wa.me/5547999447152?text=Olá!%20Gostaria%20de%20conhecer%20todos%20os%20serviços%20disponíveis."
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-[oklch(0.55_0.28_340)] hover:bg-[oklch(0.48_0.28_340)] text-white font-extrabold text-base transition-all duration-200 hover:scale-105 shadow-xl"
            style={{ fontFamily: "'Baloo 2', cursive" }}
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Falar com a Equipe
          </a>
        </div>
      </div>
    </section>
  );
}
