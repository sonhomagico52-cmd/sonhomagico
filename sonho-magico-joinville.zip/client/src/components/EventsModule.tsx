/**
 * EventsModule — Sonho Mágico Joinville CRM
 * Módulo completo de gerenciamento de eventos
 */
import { useState } from "react";
import { Plus, Trash2, Edit2, Search, Calendar, Clock, MapPin, Users, Filter } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface EventForm {
  title: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  service: string;
  status: "pending" | "confirmed" | "completed" | "cancelled";
  budget: number;
  clientId: string;
  notes: string;
}

export default function EventsModule() {
  const { events, users, addEvent, updateEvent, deleteEvent } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterService, setFilterService] = useState("all");
  const [sortBy, setSortBy] = useState<"date" | "status" | "budget">("date");

  const [formData, setFormData] = useState<EventForm>({
    title: "",
    date: "",
    time: "",
    location: "",
    attendees: 0,
    service: "Personagens Kids",
    status: "pending",
    budget: 0,
    clientId: "",
    notes: "",
  });

  const clientUsers = users.filter((u) => u.role === "client");

  // Filtrar e ordenar eventos
  let filteredEvents = events.filter((e) => {
    const matchesSearch =
      e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || e.status === filterStatus;
    const matchesService = filterService === "all" || e.service === filterService;
    return matchesSearch && matchesStatus && matchesService;
  });

  if (sortBy === "date") {
    filteredEvents.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  } else if (sortBy === "status") {
    const statusOrder = { pending: 0, confirmed: 1, completed: 2, cancelled: 3 };
    filteredEvents.sort((a, b) => statusOrder[a.status] - statusOrder[b.status]);
  } else if (sortBy === "budget") {
    filteredEvents.sort((a, b) => (b.budget || 0) - (a.budget || 0));
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.date || !formData.location || !formData.clientId) {
      toast.error("Preencha os campos obrigatórios");
      return;
    }

    if (editingId) {
      updateEvent(editingId, formData);
      toast.success("Evento atualizado com sucesso!");
    } else {
      addEvent(formData);
      toast.success("Evento criado com sucesso!");
    }

    setFormData({
      title: "",
      date: "",
      time: "",
      location: "",
      attendees: 0,
      service: "Personagens Kids",
      status: "pending",
      budget: 0,
      clientId: "",
      notes: "",
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (event: any) => {
    setFormData(event);
    setEditingId(event.id);
    setShowForm(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-[oklch(0.65_0.25_145)] text-white";
      case "pending":
        return "bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)]";
      case "completed":
        return "bg-[oklch(0.55_0.22_262)] text-white";
      case "cancelled":
        return "bg-[oklch(0.18_0.02_260)]/20 text-[oklch(0.18_0.02_260)]";
      default:
        return "bg-gray-300 text-gray-700";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "confirmed":
        return "Confirmado";
      case "pending":
        return "Pendente";
      case "completed":
        return "Realizado";
      case "cancelled":
        return "Cancelado";
      default:
        return status;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
          📅 Agenda de Eventos
        </h2>
        <button
          onClick={() => {
            setShowForm(!showForm);
            setEditingId(null);
            setFormData({
              title: "",
              date: "",
              time: "",
              location: "",
              attendees: 0,
              service: "Personagens Kids",
              status: "pending",
              budget: 0,
              clientId: "",
              notes: "",
            });
          }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
        >
          <Plus size={16} />
          Novo Evento
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">
            {editingId ? "Editar Evento" : "Novo Evento"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Título do evento *"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <select
                value={formData.clientId}
                onChange={(e) => setFormData({ ...formData, clientId: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              >
                <option value="">Selecionar Cliente *</option>
                {clientUsers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <input
                type="text"
                placeholder="Local do evento *"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <input
                type="number"
                placeholder="Número de pessoas"
                value={formData.attendees}
                onChange={(e) => setFormData({ ...formData, attendees: parseInt(e.target.value) || 0 })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <select
                value={formData.service}
                onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              >
                <option>Personagens Kids</option>
                <option>Recreação</option>
                <option>Magic Drinks Kids</option>
                <option>Brinquedos</option>
                <option>Carreta Furacão</option>
              </select>
              <input
                type="number"
                placeholder="Orçamento (R$)"
                value={formData.budget}
                onChange={(e) => setFormData({ ...formData, budget: parseFloat(e.target.value) || 0 })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              />
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none"
              >
                <option value="pending">Pendente</option>
                <option value="confirmed">Confirmado</option>
                <option value="completed">Realizado</option>
                <option value="cancelled">Cancelado</option>
              </select>
              <textarea
                placeholder="Notas"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none md:col-span-2"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="px-6 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform"
              >
                {editingId ? "Atualizar" : "Criar"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                }}
                className="px-6 py-2 rounded-lg bg-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)] font-bold"
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-4 flex-wrap">
        <div className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] bg-white">
          <Search size={18} className="text-[oklch(0.55_0.28_340)]" />
          <input
            type="text"
            placeholder="Buscar evento..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="outline-none text-sm"
          />
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none text-sm"
        >
          <option value="all">Todos os Status</option>
          <option value="pending">Pendente</option>
          <option value="confirmed">Confirmado</option>
          <option value="completed">Realizado</option>
          <option value="cancelled">Cancelado</option>
        </select>
        <select
          value={filterService}
          onChange={(e) => setFilterService(e.target.value)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none text-sm"
        >
          <option value="all">Todos os Serviços</option>
          <option value="Personagens Kids">Personagens Kids</option>
          <option value="Recreação">Recreação</option>
          <option value="Magic Drinks Kids">Magic Drinks Kids</option>
          <option value="Brinquedos">Brinquedos</option>
          <option value="Carreta Furacão">Carreta Furacão</option>
        </select>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="px-4 py-2 rounded-lg border border-[oklch(0.92_0.02_85)] focus:border-[oklch(0.55_0.28_340)] focus:outline-none text-sm"
        >
          <option value="date">Ordenar por Data</option>
          <option value="status">Ordenar por Status</option>
          <option value="budget">Ordenar por Orçamento</option>
        </select>
      </div>

      {/* Events List */}
      <div className="space-y-4">
        {filteredEvents.length > 0 ? (
          filteredEvents.map((event) => {
            const client = users.find((u) => u.id === event.clientId);
            return (
              <div
                key={event.id}
                className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)] hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)]">{event.title}</h3>
                    <p className="text-sm text-[oklch(0.18_0.02_260)]/60">Cliente: {client?.name}</p>
                  </div>
                  <div className="flex gap-2">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(event.status)}`}>
                      {getStatusLabel(event.status)}
                    </span>
                    <button
                      onClick={() => handleEdit(event)}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Edit2 size={16} className="text-[oklch(0.55_0.28_340)]" />
                    </button>
                    <button
                      onClick={() => {
                        deleteEvent(event.id);
                        toast.success("Evento deletado");
                      }}
                      className="p-2 hover:bg-[oklch(0.97_0.01_85)] rounded-lg transition-colors"
                    >
                      <Trash2 size={16} className="text-[oklch(0.65_0.25_145)]" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="flex items-center gap-2 text-sm text-[oklch(0.18_0.02_260)]/70">
                    <Calendar size={14} />
                    <span>{new Date(event.date).toLocaleDateString("pt-BR")}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[oklch(0.18_0.02_260)]/70">
                    <Clock size={14} />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[oklch(0.18_0.02_260)]/70">
                    <MapPin size={14} />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[oklch(0.18_0.02_260)]/70">
                    <Users size={14} />
                    <span>{event.attendees} pessoas</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-[oklch(0.92_0.02_85)]">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-[oklch(0.18_0.02_260)]/60">Serviço: {event.service}</p>
                    {(event.budget || 0) > 0 && (
                      <p className="text-sm font-bold text-[oklch(0.55_0.28_340)]">R$ {(event.budget || 0).toFixed(2)}</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="bg-white rounded-2xl shadow-md p-8 text-center border border-[oklch(0.92_0.02_85)]">
            <p className="text-[oklch(0.18_0.02_260)]/60 font-medium">Nenhum evento encontrado</p>
          </div>
        )}
      </div>
    </div>
  );
}
