/**
 * AutoSchedulingModule — Sonho Mágico Joinville CRM
 * Sistema de agendamento automático e sincronização com Google Calendar
 */
import { useState } from "react";
import { Calendar, AlertCircle, CheckCircle, Clock, Zap } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface ScheduleConflict {
  id: string;
  event1: string;
  event2: string;
  date: string;
  location: string;
  severity: "alto" | "medio" | "baixo";
}

export default function AutoSchedulingModule() {
  const { events } = useAuth();
  const [conflicts, setConflicts] = useState<ScheduleConflict[]>([]);
  const [autoScheduleEnabled, setAutoScheduleEnabled] = useState(false);
  const [syncGoogleCalendar, setSyncGoogleCalendar] = useState(false);

  // Detectar conflitos de agendamento
  const detectConflicts = () => {
    const newConflicts: ScheduleConflict[] = [];

    for (let i = 0; i < events.length; i++) {
      for (let j = i + 1; j < events.length; j++) {
        const event1 = events[i];
        const event2 = events[j];

        // Verificar se estão no mesmo dia e local
        if (
          new Date(event1.date).toDateString() === new Date(event2.date).toDateString() &&
          event1.location === event2.location
        ) {
          newConflicts.push({
            id: `${event1.id}-${event2.id}`,
            event1: event1.title,
            event2: event2.title,
            date: event1.date,
            location: event1.location,
            severity: "alto",
          });
        }

        // Verificar se estão no mesmo dia mas locais próximos
        if (new Date(event1.date).toDateString() === new Date(event2.date).toDateString()) {
          newConflicts.push({
            id: `${event1.id}-${event2.id}-proximity`,
            event1: event1.title,
            event2: event2.title,
            date: event1.date,
            location: `${event1.location} / ${event2.location}`,
            severity: "medio",
          });
        }
      }
    }

    setConflicts(newConflicts);
    if (newConflicts.length > 0) {
      toast.warning(`${newConflicts.length} conflito(s) de agendamento detectado(s)`);
    } else {
      toast.success("Nenhum conflito de agendamento encontrado!");
    }
  };

  const handleAutoSchedule = () => {
    if (autoScheduleEnabled) {
      setAutoScheduleEnabled(false);
      toast.success("Agendamento automático desativado");
    } else {
      detectConflicts();
      setAutoScheduleEnabled(true);
      toast.success("Agendamento automático ativado");
    }
  };

  const handleSyncGoogleCalendar = () => {
    if (syncGoogleCalendar) {
      setSyncGoogleCalendar(false);
      toast.success("Sincronização com Google Calendar desativada");
    } else {
      // Simular sincronização
      toast.loading("Sincronizando com Google Calendar...");
      setTimeout(() => {
        setSyncGoogleCalendar(true);
        toast.success("Sincronizado com Google Calendar!");
      }, 2000);
    }
  };

  const handleResolveConflict = (conflictId: string) => {
    setConflicts(conflicts.filter((c) => c.id !== conflictId));
    toast.success("Conflito resolvido!");
  };

  // Eventos próximos (próximos 7 dias)
  const upcomingEvents = events
    .filter((e) => {
      const eventDate = new Date(e.date);
      const today = new Date();
      const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
      return eventDate >= today && eventDate <= nextWeek;
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Sugestões de agendamento
  const getSchedulingSuggestions = () => {
    const suggestions: Array<{ type: string; title: string; description: string; impact: string }> = [];

    // Sugestão 1: Agrupar eventos no mesmo local
    const locationGroups = new Map<string, typeof events>();
    events.forEach((e) => {
      if (!locationGroups.has(e.location)) {
        locationGroups.set(e.location, []);
      }
      locationGroups.get(e.location)!.push(e);
    });

    locationGroups.forEach((eventsInLocation, location) => {
      if (eventsInLocation.length > 1) {
        suggestions.push({
          type: "agrupamento",
          title: `Agrupar ${eventsInLocation.length} eventos em ${location}`,
          description: "Economize tempo de deslocamento agrupando eventos no mesmo local",
          impact: "alto",
        });
      }
    });

    // Sugestão 2: Distribuir eventos por dia
    const eventsByDay = new Map<string, typeof events>();
    events.forEach((e) => {
      const day = new Date(e.date).toDateString();
      if (!eventsByDay.has(day)) {
        eventsByDay.set(day, []);
      }
      eventsByDay.get(day)!.push(e);
    });

    eventsByDay.forEach((eventsInDay, day) => {
      if (eventsInDay.length > 3) {
        suggestions.push({
          type: "distribuicao",
          title: `Distribuir ${eventsInDay.length} eventos em ${day}`,
          description: "Considere distribuir eventos em múltiplos dias para melhor qualidade",
          impact: "medio",
        });
      }
    });

    return suggestions;
  };

  const suggestions: Array<{ type: string; title: string; description: string; impact: string }> = getSchedulingSuggestions();

  return (
    <div className="space-y-6">
      {/* Header */}
      <h2 className="text-2xl font-extrabold text-[oklch(0.18_0.02_260)]" style={{ fontFamily: "'Baloo 2', cursive" }}>
        ⚡ Agendamento Automático
      </h2>

      {/* Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          onClick={handleAutoSchedule}
          className={`flex items-center justify-between p-6 rounded-2xl shadow-md border-2 transition-all ${
            autoScheduleEnabled
              ? "bg-[oklch(0.65_0.25_145)] border-[oklch(0.55_0.22_262)] text-white"
              : "bg-white border-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)]"
          }`}
        >
          <div>
            <p className="font-bold text-lg">Agendamento Automático</p>
            <p className="text-sm opacity-70">Detectar e resolver conflitos</p>
          </div>
          <Zap size={24} className={autoScheduleEnabled ? "text-white" : "text-[oklch(0.55_0.28_340)]"} />
        </button>

        <button
          onClick={handleSyncGoogleCalendar}
          className={`flex items-center justify-between p-6 rounded-2xl shadow-md border-2 transition-all ${
            syncGoogleCalendar
              ? "bg-[oklch(0.55_0.28_340)] border-[oklch(0.38_0.22_262)] text-white"
              : "bg-white border-[oklch(0.92_0.02_85)] text-[oklch(0.18_0.02_260)]"
          }`}
        >
          <div>
            <p className="font-bold text-lg">Google Calendar</p>
            <p className="text-sm opacity-70">Sincronizar eventos</p>
          </div>
          <Calendar size={24} className={syncGoogleCalendar ? "text-white" : "text-[oklch(0.55_0.28_340)]"} />
        </button>
      </div>

      {/* Conflicts */}
      {conflicts.length > 0 && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4 flex items-center gap-2">
            <AlertCircle size={20} className="text-[oklch(0.65_0.25_145)]" />
            Conflitos Detectados ({conflicts.length})
          </h3>
          <div className="space-y-3">
            {conflicts.map((conflict) => (
              <div key={conflict.id} className="flex items-center justify-between p-4 rounded-lg bg-[oklch(0.97_0.01_85)] border-l-4 border-[oklch(0.65_0.25_145)]">
                <div className="flex-1">
                  <p className="font-bold text-[oklch(0.18_0.02_260)]">{conflict.event1} × {conflict.event2}</p>
                  <p className="text-xs text-[oklch(0.18_0.02_260)]/60">
                    {new Date(conflict.date).toLocaleDateString("pt-BR")} em {conflict.location}
                  </p>
                </div>
                <button
                  onClick={() => handleResolveConflict(conflict.id)}
                  className="px-4 py-2 rounded-lg bg-[oklch(0.55_0.28_340)] text-white font-bold hover:scale-105 transition-transform text-sm"
                >
                  Resolver
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upcoming Events */}
      <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
        <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4 flex items-center gap-2">
          <Clock size={20} />
          Próximos Eventos (7 dias)
        </h3>
        {upcomingEvents.length > 0 ? (
          <div className="space-y-3">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="flex items-center justify-between p-4 rounded-lg bg-[oklch(0.97_0.01_85)]">
                <div className="flex-1">
                  <p className="font-bold text-[oklch(0.18_0.02_260)]">{event.title}</p>
                  <p className="text-xs text-[oklch(0.18_0.02_260)]/60">
                    {new Date(event.date).toLocaleDateString("pt-BR")} em {event.location}
                  </p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                  event.status === "confirmed"
                    ? "bg-[oklch(0.65_0.25_145)] text-white"
                    : "bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)]"
                }`}>
                  {event.status === "confirmed" ? "Confirmado" : "Pendente"}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-[oklch(0.18_0.02_260)]/60 text-sm">Nenhum evento nos próximos 7 dias</p>
        )}
      </div>

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <div className="bg-white rounded-2xl shadow-md p-6 border border-[oklch(0.92_0.02_85)]">
          <h3 className="text-lg font-bold text-[oklch(0.18_0.02_260)] mb-4">💡 Sugestões de Agendamento</h3>
          <div className="space-y-3">
            {suggestions.map((suggestion, idx) => (
              <div key={idx} className="flex items-start gap-3 p-4 rounded-lg bg-[oklch(0.97_0.01_85)]">
                <div className="w-8 h-8 rounded-full bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)] flex items-center justify-center flex-shrink-0 font-bold text-sm">
                  💡
                </div>
                <div className="flex-1">
                  <p className="font-bold text-[oklch(0.18_0.02_260)]">{suggestion.title}</p>
                  <p className="text-xs text-[oklch(0.18_0.02_260)]/60 mt-1">{suggestion.description}</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-bold whitespace-nowrap ${
                  suggestion.impact === "alto"
                    ? "bg-[oklch(0.65_0.25_145)] text-white"
                    : "bg-[oklch(0.88_0.18_85)] text-[oklch(0.18_0.02_260)]"
                }`}>
                  {suggestion.impact === "alto" ? "Alto" : "Médio"}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Info */}
      <div className="p-4 rounded-lg bg-[oklch(0.97_0.01_85)] border border-[oklch(0.92_0.02_85)]">
        <p className="text-sm text-[oklch(0.18_0.02_260)]/70">
          💡 <strong>Dica:</strong> O agendamento automático ajuda a evitar conflitos de datas e locais. Sincronize com Google Calendar para manter tudo organizado.
        </p>
      </div>
    </div>
  );
}
