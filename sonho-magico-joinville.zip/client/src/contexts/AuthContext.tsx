/**
 * AuthContext — Sonho Mágico Joinville CRM
 * Gerenciamento de autenticação e dados do usuário
 */
import React, { createContext, useContext, useState, useEffect } from "react";

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: "client" | "admin";
  createdAt: string;
}

export interface Event {
  id: string;
  clientId: string;
  title: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  service: string;
  status: "pending" | "confirmed" | "completed" | "cancelled";
  budget?: number;
  notes?: string;
  createdAt: string;
}

export interface Quote {
  id: string;
  clientId: string;
  eventId?: string;
  title: string;
  description: string;
  amount: number;
  status: "pending" | "approved" | "rejected";
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isSuperAdmin: boolean;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, phone: string, password: string) => boolean;
  logout: () => void;
  validateSuperAdminPassword: (password: string) => boolean;
  events: Event[];
  quotes: Quote[];
  users: User[];
  addEvent: (event: Omit<Event, "id" | "createdAt">) => void;
  updateEvent: (id: string, event: Partial<Event>) => void;
  deleteEvent: (id: string) => void;
  addQuote: (quote: Omit<Quote, "id" | "createdAt">) => void;
  updateQuote: (id: string, quote: Partial<Quote>) => void;
  addUser: (user: Omit<User, "id" | "createdAt">) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Dados iniciais simulados
const ADMIN_PASSWORD = "admin123";

const INITIAL_USERS: User[] = [
  {
    id: "admin-001",
    name: "Admin Sonho Mágico",
    email: "admin@sonhomagico.com",
    phone: "(47) 99944-7152",
    role: "admin",
    createdAt: new Date().toISOString(),
  },
  {
    id: "client-001",
    name: "João Silva",
    email: "joao@email.com",
    phone: "(47) 98765-4321",
    role: "client",
    createdAt: new Date().toISOString(),
  },
];

const INITIAL_EVENTS: Event[] = [
  {
    id: "event-001",
    clientId: "client-001",
    title: "Festa de Aniversário - Tema Mickey",
    date: "2026-03-25",
    time: "14:00",
    location: "Bairro Centro, Joinville",
    attendees: 30,
    service: "Personagens Kids",
    status: "confirmed",
    budget: 500,
    createdAt: new Date().toISOString(),
  },
];

const INITIAL_QUOTES: Quote[] = [];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [events, setEvents] = useState<Event[]>(INITIAL_EVENTS);
  const [quotes, setQuotes] = useState<Quote[]>(INITIAL_QUOTES);

  // Carregar dados do localStorage ao iniciar
  useEffect(() => {
    const savedUser = localStorage.getItem("currentUser");
    const savedUsers = localStorage.getItem("users");
    const savedEvents = localStorage.getItem("events");
    const savedQuotes = localStorage.getItem("quotes");

    if (savedUser) setUser(JSON.parse(savedUser));
    const savedSuperAdmin = localStorage.getItem("isSuperAdmin");
    if (savedSuperAdmin === "true") setIsSuperAdmin(true);
    if (savedUsers) setUsers(JSON.parse(savedUsers));
    if (savedEvents) setEvents(JSON.parse(savedEvents));
    if (savedQuotes) setQuotes(JSON.parse(savedQuotes));
  }, []);

  // Salvar dados no localStorage sempre que mudarem
  useEffect(() => {
    localStorage.setItem("users", JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem("events", JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem("quotes", JSON.stringify(quotes));
  }, [quotes]);

  const login = (email: string, password: string): boolean => {
    // Buscar usuário (simulado - sem verificação real de senha)
    const foundUser = users.find((u) => u.email === email);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem("currentUser", JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const signup = (name: string, email: string, phone: string, password: string): boolean => {
    // Verificar se email já existe
    if (users.some((u) => u.email === email)) {
      return false;
    }

    const newUser: User = {
      id: `client-${Date.now()}`,
      name,
      email,
      phone,
      role: "client",
      createdAt: new Date().toISOString(),
    };

    setUsers([...users, newUser]);
    setUser(newUser);
    localStorage.setItem("currentUser", JSON.stringify(newUser));
    return true;
  };

  const logout = () => {
    setUser(null);
    setIsSuperAdmin(false);
    localStorage.removeItem("currentUser");
    localStorage.removeItem("isSuperAdmin");
  };

  const validateSuperAdminPassword = (password: string): boolean => {
    if (user?.role === "admin" && password === ADMIN_PASSWORD) {
      setIsSuperAdmin(true);
      localStorage.setItem("isSuperAdmin", "true");
      return true;
    }
    return false;
  };

  const addEvent = (event: Omit<Event, "id" | "createdAt">) => {
    const newEvent: Event = {
      ...event,
      id: `event-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setEvents([...events, newEvent]);
  };

  const updateEvent = (id: string, event: Partial<Event>) => {
    setEvents(events.map((e) => (e.id === id ? { ...e, ...event } : e)));
  };

  const deleteEvent = (id: string) => {
    setEvents(events.filter((e) => e.id !== id));
  };

  const addQuote = (quote: Omit<Quote, "id" | "createdAt">) => {
    const newQuote: Quote = {
      ...quote,
      id: `quote-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setQuotes([...quotes, newQuote]);
  };

  const updateQuote = (id: string, quote: Partial<Quote>) => {
    setQuotes(quotes.map((q) => (q.id === id ? { ...q, ...quote } : q)));
  };

  const addUser = (user: Omit<User, "id" | "createdAt">) => {
    const newUser: User = {
      ...user,
      id: `user-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setUsers([...users, newUser]);
  };

  const updateUser = (id: string, user: Partial<User>) => {
    setUsers(users.map((u) => (u.id === id ? { ...u, ...user } : u)));
  };

  const deleteUser = (id: string) => {
    setUsers(users.filter((u) => u.id !== id));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isSuperAdmin,
        login,
        signup,
        logout,
        validateSuperAdminPassword,
        events,
        quotes,
        users,
        addEvent,
        updateEvent,
        deleteEvent,
        addQuote,
        updateQuote,
        addUser,
        updateUser,
        deleteUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
}

// Hook para verificar se é super admin
export function useSuperAdmin() {
  const { user, isSuperAdmin, validateSuperAdminPassword } = useAuth();
  return {
    isSuperAdmin: user?.role === "admin" && isSuperAdmin,
    validatePassword: validateSuperAdminPassword,
  };
}
